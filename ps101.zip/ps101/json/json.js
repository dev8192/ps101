function test1() {
    const obj = {name: 'Vasya', age: 30}
    // const str = JSON.stringify(obj)
    const str = JSON.stringify(obj, null, 4)
    console.log(str)
    console.log(typeof str)
}

function test2() {
    const str = '{"name":"Vasya","age":30}'
    const obj = JSON.parse(str)
    console.log(obj)
    console.log(typeof obj)
}

test1()
console.log('-'.repeat(30))
test2()
