function test1 {
    # $obj = [PSCustomObject]@{
    $obj = @{
        name = 'Vasya'
        age  = 30
    }
    $str = $obj | ConvertTo-Json
    # $str = $obj | ConvertTo-Json -Compress
    Write-Host $str
    Write-Host $str.GetType().Name
}

function test2 {
    $str = '{"name":"Vasya","age":30}'
    $obj = $str | ConvertFrom-Json
    Write-Host $obj
    Write-Host $obj.GetType().Name
}

test1
Write-Host ('-' * 30)
test2
