function Test1 {
    for ($i = 0; $i -lt 5; $i++) {
        Write-Output "for: $i"
    }
}

function Test1 {
    $i = 0
    while ($i -lt 5) {
        Write-Output "while: $i"
        $i++
    }
}

function Test1 {
    $i = 0
    do {
        Write-Output "do-while: $i"
        $i++
    } while ($i -lt 5)
}

function Test {
    $i = 0
    do {
        Write-Output "do-until: $i"
        $i++
    } until ($i -ge 5)
}

Test
