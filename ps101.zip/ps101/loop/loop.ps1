<#
    loop.ps1
    Demonstrates different types of loops in PowerShell.
#>

function Test1 {
    $items = "apple", "banana", "cherry"
    foreach ($item in $items) {
        Write-Output "'$item'"
    }
}

function Test {
    $items = 1..5  # creates array [1,2,3,4,5]
    $items | ForEach-Object {
        Write-Output "Number: $_"
    }
}

function Test {
    for ($i = 0; $i -lt 5; $i++) {
        Write-Output "Index: $i"
    }
}

function Test {
    $count = 3
    while ($count -gt 0) {
        Write-Output "Countdown: $count"
        $count--
    }
}

function Test {
    $n = 0
    do {
        Write-Output "n is $n"
        $n++
    } while ($n -lt 3)
}

Test
