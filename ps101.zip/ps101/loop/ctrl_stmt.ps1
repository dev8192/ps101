<#
    Control statements
#>

function Test1 {
    for ($i = 0; $i -lt 10; $i++) {
        Write-Host "Number: $i"
        if ($i -eq 5) {
            Write-Host "Break"
            break
        }
    }
}

function Test {
    for ($i = 0; $i -lt 10; $i++) {
        if ($i % 2 -ne 0) {
            continue
        }
        Write-Host "Odd Number: $i"
    }
}

Test
