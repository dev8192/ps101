function Test1 {
    for ($i = 0; $i -le 10; $i += 2) {
        $i
    }
}

function Test1 {
    $nums = 0..10
    $evens = $nums | Where-Object { $_ % 2 -eq 0 }
    $evens
}

function Test {
    $nums = 0..10
    $evens = $nums | Where-Object { $_ % 2 -eq 0 } | ForEach-Object { Write-Host $_ }
}

Test
