function Test1 {
    $colors = "Red", "Green", "Blue"
    foreach ($color in $colors) {
        Write-Output "$color"
    }
}

function Test1 {
    $colors = @("Cyan", "Magenta", "Yellow")
    for ($i = 0; $i -lt $colors.Count; $i++) {
        Write-Output "$($colors[$i])"
    }
}

function Test1 {
    foreach ($num in 1..5) {
        Write-Host "Number: $num"
    }
}

function Test1 {
    $items = 1..5
    $items | ForEach-Object {
        Write-Output "Number: $_"
    }
}

function Test {
    1..5 | ForEach-Object   -Begin { Write-Host "Starting..." } `
                            -Process { Write-Host "Processing: $_" } `
                            -End { Write-Host "Completed!" }
}

Test
