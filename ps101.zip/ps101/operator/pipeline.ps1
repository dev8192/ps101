
function Test {
    1..5 | ForEach-Object { $_ * 2 }
}

function Test1 {
    Get-Process | Sort-Object CPU -Descending | Select-Object -First 5
}

Test
