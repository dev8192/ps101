<#
0000000000000000000000000000000010000000000000000000000000000000
#>

function Test {
    $num = 1
    for ($i = 0; $i -lt 64; $i++) {
        [Convert]::ToString($num, 2).PadLeft(64, '0')
        $num = $num -shl 1
    }
}

function Test {
    $num = 15
    [Convert]::ToString($num, 2).PadLeft(32, '0')
    $num = $num -shl 4
    [Convert]::ToString($num, 2).PadLeft(32, '0')
    $num = $num -shr 4
    [Convert]::ToString($num, 2).PadLeft(32, '0')
}

function Test {
    $num = -2147483648
    [Convert]::ToString($num, 2).PadLeft(64, '0')
    $num = $num -shr 31
    [Convert]::ToString($num, 2).PadLeft(64, '0')
    $num
    $num -eq -1
}

# Method invocation failed because [System.Numerics.BigInteger] does not contain a method named 'LeftShift'.
function Test1 {
    [bigint]$largeValue = [Math]::Pow(2, 70)
    $result = [System.Numerics.BigInteger]::LeftShift($largeValue, 2)
    Write-Host "Large value shifted left by 2 positions."
    # Write-Host "Result type: $($result.GetType().Name)"
}

Test
