function Test {
    $text = "PowerShell"
    "$($text -match 'power')"
    "$($text -cmatch 'power')" # case-sensitive match
    "$($text -notmatch 'banana')"
    "$($text -notmatch 'PowerShell')"
}

Test
