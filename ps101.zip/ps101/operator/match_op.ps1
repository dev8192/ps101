function Test {
    $text = "PowerShell"
    "$($text -match 'power')"
    "$($text -cmatch 'power')" # case-sensitive match
    "$($text -notmatch 'banana')"
    "$($text -notmatch 'PowerShell')"
}

function Test {
    "123-456" -match "\d{3}-\d{3}"
    "123-456" -match "\d{3}-\d{4}"
}

Test
