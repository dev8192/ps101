
function test {
    $str = "123"
    $str
    $str.GetType().FullName

    $num = $str -as [int]
    $num
    $num.GetType().FullName
}

function test {
    $str = "hello"
    $str
    $str.GetType().FullName

    $num = $str -as [int]
    $num -eq $null
}

function test {
    $value = "42"
    $cast = $value -as [Nullable[int]]

    "Input: $value"
    "Cast result: $cast"
    "Underlying type: $($cast.GetType().FullName)"
}

function Example_TypeCheckPattern {
    param($inputValue)

    $num = $inputValue -as [int]

    if ($num -ne $null) {
        "Value '$inputValue' is an integer. Doubled: $($num * 2)"
    }
    else {
        "Value '$inputValue' is NOT an integer."
    }
}

# ---------------------------------------------
# Example 9: Casting to a .NET generic type
# ---------------------------------------------
function Example_GenericTypeCast {
    $dict = New-Object "System.Collections.Generic.Dictionary[string,int]"
    $dict.Add("A", 1)

    $cast = $dict -as "System.Collections.Generic.IDictionary[string,int]"

    "Dictionary type: $($dict.GetType().FullName)"
    "Cast to IDictionary[string,int] successful: $($cast -ne $null)"
}

# ---------------------------------------------
# Example 10: Casting COM objects
# ---------------------------------------------
function Example_ComObjectCast {
    # Only works on Windows with Excel installed
    try {
        $excel = New-Object -ComObject Excel.Application
        $cast = $excel -as [System.__ComObject]

        "COM object type: $($excel.GetType().FullName)"
        "Cast to System.__ComObject successful: $($cast -ne $null)"
        $excel.Quit()
    }
    catch {
        "Excel COM object not available on this system."
    }
}

test
