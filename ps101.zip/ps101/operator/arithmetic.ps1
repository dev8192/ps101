function Test {
    $a = 10
    $b = 3
    Write-Output "$a + $b = $($a + $b)"
    Write-Output "$a - $b = $($a - $b)"
    Write-Output "$a * $b = $($a * $b)"
    Write-Output "$a / $b = $($a / $b)"
    Write-Output "$a % $b = $($a % $b)"
}

Test
