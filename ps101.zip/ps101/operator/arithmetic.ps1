function Test {
    $a = 10
    $b = 3
    "$a + $b = $($a + $b)"
    "$a - $b = $($a - $b)"
    "$a * $b = $($a * $b)"
    "$a / $b = $($a / $b)"
    "$a % $b = $($a % $b)"
}

Test
