$arr = "cat", "dog", "bird"

function Test {
    "$($arr -contains 'dog')"
    "$($arr -contains 'fish')"
}

function Test {
    "$($arr -notcontains 'dog')"
    "$($arr -notcontains 'fish')"
}

function Test {
    "$('dog' -in $arr)"
    "$('fish' -in $arr)"
}

function Test {
    "$('dog' -notin $arr)"
    "$('fish' -notin $arr)"
}

Test
