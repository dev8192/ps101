function Test {
    # $num = 42
    # [string]$num = 42
    $num = [string]42

    "$($num -is [int])"
    "$($num -is [string])"
    "$($num -isnot [string])"
}

Test
