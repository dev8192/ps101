<#
    operators-demo.ps1
    Demonstrates common PowerShell operators with examples.
#>

function Test1 {
    $a = 10
    $b = 3
    Write-Output "$a + $b = $($a + $b)"
    Write-Output "$a - $b = $($a - $b)"
    Write-Output "$a * $b = $($a * $b)"
    Write-Output "$a / $b = $($a / $b)"
    Write-Output "$a % $b = $($a % $b)"
}

function Test {
    $x = 5
    $y = 10
    Write-Output "$x -eq $y : $($x -eq $y)" # equal
    Write-Output "$x -ne $y : $($x -ne $y)" # not equal
    Write-Output "$x -lt $y : $($x -lt $y)" # less than
    Write-Output "$x -gt $y : $($x -gt $y)" # greater than
    Write-Output "$x -le $y : $($x -le $y)" # less than or equal to
    Write-Output "$x -ge $y : $($x -ge $y)" # greater than or equal to
}

function Test {
    $a = "hello"
    $b = "HELLO"

    Write-Output "$($a -eq $b)"
    Write-Output "$($a -ceq $b)"
}

# ---------------------------------------
# 4. Logical operators
# ---------------------------------------
function Show-LogicalOperators {
    $t = $true
    $f = $false

    Write-Output "`nLogical:"
    Write-Output "t -and f: $($t -and $f)"
    Write-Output "t -or f:  $($t -or $f)"
    Write-Output "-not t:   $(-not $t)"
}

# ---------------------------------------
# 5. Assignment operators
# ---------------------------------------
function Show-AssignmentOperators {
    $x = 5
    Write-Output "`nAssignment:"
    Write-Output "Start: $x"

    $x += 3
    Write-Output "After x += 3: $x"

    $x -= 2
    Write-Output "After x -= 2: $x"

    $x *= 4
    Write-Output "After x *= 4: $x"
}

# ---------------------------------------
# 6. Array operators
# ---------------------------------------
function Show-ArrayOperators {
    $arr = 1, 2, 3, 4, 5

    Write-Output "`nArray operators:"
    Write-Output "Contains 3: $($arr -contains 3)"
    Write-Output "Not contains 9: $($arr -notcontains 9)"
    Write-Output "In operator (3 -in arr): $(3 -in $arr)"
    Write-Output "Not in operator (9 -notin arr): $(9 -notin $arr)"
}

# ---------------------------------------
# 7. Type operators
# ---------------------------------------
function Show-TypeOperators {
    $num = 42

    Write-Output "`nType operators:"
    Write-Output "Is int: $($num -is [int])"
    Write-Output "Is string: $($num -is [string])"
    Write-Output "Is not string: $($num -isnot [string])"
}

# ---------------------------------------
# 8. Match operators (regex)
# ---------------------------------------
function Show-MatchOperators {
    $text = "PowerShell is powerful"

    Write-Output "`nMatch operators:"
    Write-Output "Match 'power': $($text -match 'power')"
    Write-Output "Case-sensitive match: $($text -cmatch 'power')"
    Write-Output "Not match 'banana': $($text -notmatch 'banana')"
}

# ---------------------------------------
# 9. Null-coalescing operators (PowerShell 7+)
# ---------------------------------------
# function Show-NullCoalescing {
#     $value = $null

#     Write-Output "`nNull-coalescing:"
#     Write-Output "value ?? 'fallback' = $($value ?? 'fallback')"

#     $value2 = "hello"
#     Write-Output "value2 ?? 'fallback' = $($value2 ?? 'fallback')"
# }

# ---------------------------------------
# 10. Pipeline operator
# ---------------------------------------
function Show-PipelineOperator {
    Write-Output "`nPipeline:"
    1..5 | ForEach-Object { $_ * 2 }
}

Test
