
function Test {
    $x = 5
    $y = 10
    Write-Output "$x -eq $y : $($x -eq $y)" # equal
    Write-Output "$x -ne $y : $($x -ne $y)" # not equal
    Write-Output "$x -lt $y : $($x -lt $y)" # less than
    Write-Output "$x -gt $y : $($x -gt $y)" # greater than
    Write-Output "$x -le $y : $($x -le $y)" # less than or equal to
    Write-Output "$x -ge $y : $($x -ge $y)" # greater than or equal to
}

function Test {
    $a = "hello"
    $b = "HELLO"

    Write-Output "$($a -eq $b)"
    Write-Output "$($a -ceq $b)"
}

Test
