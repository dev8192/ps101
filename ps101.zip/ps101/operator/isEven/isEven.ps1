
function test {
    'functional style'
    1..6 | ForEach-Object {
        if ($_ % 2 -eq 0) {
            "$_ is even"
        } else {
            "$_ is odd"
        }
    }
}

function test {
    'procedural style'
    for ($i = 1; $i -le 6; $i++) {
        if ($i % 2 -eq 0) {
            "$i is even"
        } else {
            "$i is odd"
        }
    }
}

test
