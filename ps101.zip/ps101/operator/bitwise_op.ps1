function Test {
    [Convert]::ToString(15, 2).PadLeft(8, '0')
    [Convert]::ToString(128 -bor 64 -bor 32 -bor 16, 2).PadLeft(8, '0')
}

# 11111111111111111111111111110000
function Test {
    $num = 15
    [Convert]::ToString($num, 2).PadLeft(32, '0')

    $num = -bnot $num
    [Convert]::ToString($num, 2).PadLeft(32, '0')
}

Test
