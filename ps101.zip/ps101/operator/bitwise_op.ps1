
function Test1 {
    [Convert]::ToString(15, 2).PadLeft(8, '0')
    [Convert]::ToString(240, 2).PadLeft(8, '0')

    $low4 = (8 -bor 4 -bor 2 -bor 1)
    [Convert]::ToString($low4, 2).PadLeft(8, '0')
    $high4 = (128 -bor 64 -bor 32 -bor 16)
    [Convert]::ToString($high4, 2).PadLeft(8, '0')
}

# 11111111111111111111111111110000
function Test {
    $num = 15
    [Convert]::ToString($num, 2).PadLeft(32, '0')

    $num = -bnot $num
    [Convert]::ToString($num, 2).PadLeft(32, '0')
}

Test
