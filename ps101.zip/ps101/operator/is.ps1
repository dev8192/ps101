
function test {
    "Hello" -is [string]
    "Hello" -is [int]
    123 -is [string]
    123 -is [int]
}

function test {
    $isString = "Hello" -is [string]
    $isString
    $isString.GetType()
}

test
