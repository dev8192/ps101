function Test {
    $num = 5
    "$num" # 5

    $num += 3
    "$num" # 8

    $num -= 2
    "$num" # 6

    $num *= 4
    "$num" # 24
}

Test
