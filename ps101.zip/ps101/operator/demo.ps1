


# 6. Type Operators: Check or convert object types.
function Show-TypeOperators {
    Write-Host "--- Type Operators (-is, -as) ---"
    $isString = "Hello" -is [string]
    $converted = "100" -as [int]
    Write-Host "Is 'Hello' a string? $isString"
    Write-Host "Converted '100' to integer: $($converted.GetType().Name)"
}

# 7. String Operators: Manipulation of strings (split and join).
function Show-StringOperators {
    Write-Host "--- String Operators (-split, -join) ---"
    $csv = "Red,Green,Blue"
    $splitArray = $csv -split ","   # Splits string into array
    $joinedString = $splitArray -join " | " # Joins array into string
    Write-Host "Split first element: $($splitArray[0])"
    Write-Host "Joined string: $joinedString"
}

# 8. Replacement Operator: Replaces parts of a string using Regex.
function Show-ReplacementOperator {
    Write-Host "--- Replacement Operator (-replace) ---"
    $original = "The quick brown fox"
    $new = $original -replace "brown", "white"
    Write-Host "Original: $original"
    Write-Host "Replaced: $new"
}
