function Test {
    $isAdmin = $true
    $isLogged = $true
    $accountLocked = $false

    if ($isAdmin -and $isLogged) {
        Write-Host "Admin access granted." -ForegroundColor Green
    }
    if ($isLogged -and -not $accountLocked) {
        Write-Host "User session is valid." -ForegroundColor Green
    }
    if ($isAdmin -or $isLogged) {
        Write-Host "At least one condition met." -ForegroundColor DarkGreen
    }
}

Test
