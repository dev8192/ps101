
function Test {
    "$($true -and $true)" # true
    "$($true -and $false)" # false
    "$($false -and $true)" # false
    "$($false -and $false)" # false
}

function Test {
    "$($true -or $true)" # true
    "$($true -or $false)" # true
    "$($false -or $true)" # true
    "$($false -or $false)" # false
}

function Test {
    "$($true -xor $true)" # false
    "$($true -xor $false)" # true
    "$($false -xor $true)" # true
    "$($false -xor $false)" # false
}

function Test1 {
    "$(-not $true)" # false
    "$(-not $false)" # true
}

function Test1 {
    $isAdmin = $true
    $isLogged = $true
    $accountLocked = $false

    if ($isAdmin -and $isLogged) {
        Write-Host "Admin access granted." -ForegroundColor Green
    }
    if ($isLogged -and -not $accountLocked) {
        Write-Host "User session is valid." -ForegroundColor Green
    }
    if ($isAdmin -or $isLogged) {
        Write-Host "At least one condition met." -ForegroundColor DarkGreen
    }
}

Test
