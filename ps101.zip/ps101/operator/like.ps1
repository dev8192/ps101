function Test {
    "PowerShell" -like "*Shell"
    "JavaScript" -like "*Shell"
}

Test
