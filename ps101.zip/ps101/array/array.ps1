<#
    array-demo.ps1
    Demonstrates common array operations in PowerShell.
#>

function Test {
    $numbers = 1, 2, 3, 4
    $words   = @("apple", "banana", "cherry")
    $range   = 1..5   # creates [1,2,3,4,5]

    Write-Output "Numbers: $numbers"
    Write-Output "Words:   $words"
    Write-Output "Range:   $range"
}

function Test1 {
    $fruits = "apple", "banana", "cherry"
    $fruits.Count
}

function Test {
    $fruits = "apple", "banana", "cherry"
    "$fruits"
    $fruits -join ' '
    $fruits -join '  '
    $fruits -join ', '
    $fruits -join '; '
}

function Test1 {
    $var1 = @("apple")
    $var1.GetType().Name
    $var2 = "apple"
    $var2.GetType().Name
}

function Test {
    $arr = "a", "b", "c", "d"
    Write-Output "'$($arr[0])'"
    Write-Output "'$($arr[1])'"
    Write-Output "'$($arr[2])'"
    Write-Output "'$($arr[3])'"
    Write-Output "'$($arr[4])'"
}

function Test1 {
    $arr = "a", "b", "c", "d"
    Write-Output "'$($arr[-1])'"
    Write-Output "'$($arr[-2])'"
    Write-Output "'$($arr[-3])'"
    Write-Output "'$($arr[-4])'"
    Write-Output "'$($arr[-5])'"
}

function Test1 {
    $arr = 1, 2, 3
    Write-Output "$arr"
    Write-Output $arr.GetHashCode()

    $arr = $arr + 4
    Write-Output "$arr"
    Write-Output $arr.GetHashCode()
}

function Test1 {
    $arr = 1, 2, 3
    Write-Output "$arr"
    Write-Output "$([System.Runtime.CompilerServices.RuntimeHelpers]::GetHashCode($arr))"
    Write-Output $arr.GetHashCode()
}

function Test1 {
    $num = 123
    Write-Output $num.GetHashCode()
    $arr = 1, 2, 3
    Write-Output $arr.GetHashCode()
}

function Test1 {
    $arr = 1, 2, 3
    Write-Output "$arr"
    Write-Output $arr
}

Test
