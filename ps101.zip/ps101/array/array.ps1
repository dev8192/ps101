<#
    array-demo.ps1
    Demonstrates common array operations in PowerShell.
#>

function Test1 {
    $numbers = 1, 2, 3, 4
    $words   = @("apple", "banana", "cherry")
    $range   = 1..5   # creates [1,2,3,4,5]

    Write-Output "Numbers: $numbers"
    Write-Output "Words:   $words"
    Write-Output "Range:   $range"
}

function Test1 {
    $arr1 = @("apple", "banana", "cherry")
    $arr2 = "apple", "banana", "cherry"
    Write-Output $arr1
    Write-Output $arr2
}

function Test1 {
    $fruits = "apple", "banana", "cherry"
    $fruits.Count
}

function Test1 {
    $fruits = "apple", "banana", "cherry"
    "$fruits"
    $fruits -join ', '
    $fruits -join '; '
}

function Test1 {
    $var1 = @("apple")
    $var1.GetType().Name
    $var2 = "apple"
    $var2.GetType().Name
}

function Test1 {
    $arr = "a", "b", "c", "d"
    Write-Output "'$($arr[0])'"
    Write-Output "'$($arr[1])'"
    Write-Output "'$($arr[2])'"
    Write-Output "'$($arr[3])'"
    Write-Output "'$($arr[4])'"
}

function Test1 {
    $arr = "a", "b", "c", "d"
    Write-Output "'$($arr[-1])'"
    Write-Output "'$($arr[-2])'"
    Write-Output "'$($arr[-3])'"
    Write-Output "'$($arr[-4])'"
    Write-Output "'$($arr[-5])'"
}

function Test1 {
    $arr = 1, 2, 3
    Write-Output $arr

    $arr += 4
    $arr += 5
    Write-Output $arr

    $arr = $arr | Where-Object { $_ -ne 3 }
    Write-Output $arr
}

function Test {
    $arr = "red", "green", "blue"
    foreach ($color in $arr) {
        Write-Output " - $color"
    }
}

function Test1 {
    $arr = "red", "green", "blue"
    $arr | ForEach-Object {
        Write-Output " * $_"
    }
}

function Show-ArrayFunctional {
    $nums = 1..10

    # Filter (like JS .filter)
    $evens = $nums | Where-Object { $_ % 2 -eq 0 }

    # Map (like JS .map)
    $squares = $nums | ForEach-Object { $_ * $_ }

    # Reduce (PowerShell doesn't have reduce, but you can simulate it)
    $sum = 0
    $nums | ForEach-Object { $sum += $_ }

    Write-Output "Evens:   $evens"
    Write-Output "Squares: $squares"
    Write-Output "Sum:     $sum"
}

# ---------------------------------------
# 6. Sorting arrays
# ---------------------------------------
function Show-ArraySorting {
    $arr = 5, 3, 9, 1, 7

    Write-Output "Original: $arr"
    Write-Output "Sorted ascending:   $($arr | Sort-Object)"
    Write-Output "Sorted descending:  $($arr | Sort-Object -Descending)"
}

# ---------------------------------------
# 7. Checking membership
# ---------------------------------------
function Show-ArrayContains {
    $arr = "cat", "dog", "bird"

    Write-Output "Contains 'dog': $($arr -contains 'dog')"
    Write-Output "Contains 'fish': $($arr -contains 'fish')"
}

# ---------------------------------------
# 8. Unique values
# ---------------------------------------
function Show-ArrayUnique {
    $arr = 1, 2, 2, 3, 3, 3, 4

    $unique = $arr | Sort-Object -Unique

    Write-Output "Unique values: $unique"
}

function Test1 {
    $arr = 1, 2, 3
    Write-Output "$arr"
    Write-Output $arr.GetHashCode()

    $arr = $arr + 4
    Write-Output "$arr"
    Write-Output $arr.GetHashCode()
}

function Test1 {
    $arr = 1, 2, 3
    Write-Output "$arr"
    Write-Output "$([System.Runtime.CompilerServices.RuntimeHelpers]::GetHashCode($arr))"
    Write-Output $arr.GetHashCode()
}

function Test1 {
    $num = 123
    Write-Output $num.GetHashCode()
    $arr = 1, 2, 3
    Write-Output $arr.GetHashCode()
}

function Test1 {
    $arr = 1, 2, 3
    Write-Output "$arr"
    Write-Output $arr
}

Test
