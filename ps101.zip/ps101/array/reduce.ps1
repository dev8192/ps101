function Test1 {
    $nums = 1..10
    Write-Output "$nums"

    $sum = 0
    $nums | ForEach-Object { $sum += $_ }
    Write-Output "$sum"
}

function Test {
    $nums = 1..10
    Write-Output "$nums"

    $sum = 0
    for ($i = 0; $i -lt $nums.Count; $i++) {
        $sum += $nums[$i]
    }
    Write-Output "$sum"
}

Test
