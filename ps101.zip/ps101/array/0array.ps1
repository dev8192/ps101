# basic example of array
$fruits = @("apple", "banana", "cherry")
foreach ($fruit in $fruits) {
    $fruit    
}
