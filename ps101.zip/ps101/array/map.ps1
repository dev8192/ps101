
function Test {
    $nums = 1..10
    Write-Output "$nums"

    $evens = $nums | Where-Object { $_ % 2 -eq 0 }
    Write-Output "$evens"

    $squares = $nums | ForEach-Object { $_ * $_ }
    Write-Output "$squares"
}

Test
