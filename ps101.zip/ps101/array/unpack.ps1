function test {
    $inner = 5, 10
    $array = @(1, 2, "$inner")
    $array.count
    "$array"
}

function test1 {
    $inner = 5, 10
    $array = @(1, 2, $inner)
    # $array = @(1, 2, $($inner))
    $array.count
    "$array"
}

function test {
    $inner = 5, 10
    # $array = @(1, 2, $inner)
    # $array = @(1, 2, $($inner))
    $array = @(1, 2, "$inner")
    $array[0].GetType()
    $array[1].GetType()
    $array[2].GetType()
}

function test {
    $inner = 5, 10
    $array = @(1, 2, $inner | Write-Output)
    $array.count
    "$array"
}

test
