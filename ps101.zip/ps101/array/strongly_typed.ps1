<#
How to force a strongly typed array ([int[]], [string[]])
#>

function Test {
    $numbers = 1, 2, 3
    $numbers.GetType().Name
    
    $letters = 'a', 'b', 'c'
    $letters.GetType().Name

    [int[]]$numbers = 1, 2, 3
    $numbers.GetType().Name
    
    [string[]]$letters = 'a', 'b', 'c'
    $letters.GetType().Name
}

function Test {
    $arr = 5, 10, 15
    "$arr"
    $arr.GetType().Name
}

function Test {
    # [string[]]$arr = 5, 10, 15
    $arr = 5, 10, 15
    "$arr"
    $arr[0] + 1
    $arr.GetType().Name
}

function Test {
    [string[]]$arr = 10, 20, 30
    $arr[0] + 1
    [int[]]$arr = 40, 50, 60
    # $arr = 40, 50, 60
    $arr[0] + 1
}

function Test {
    $arr = @(5, 10, 15)
    $arr.GetType().Name # Object[]

    $arr = [int[]]@(5, 10, 15)
    $arr.GetType().Name # Int32[]
    
    $arr = [string[]]@(5, 10, 15)
    $arr.GetType().Name # String[]
}

function Test {
    [string[]]$arr = @(5, 10, 15)
    $arr.GetType().Name # String[]

    $arr = [int[]]@(5, 10, 15)
    $arr.GetType().Name # String[]
}

Test
