
function Test1 {
    $arr = "red", "green", "blue"
    foreach ($color in $arr) {
        Write-Output " - $color"
    }
}

function Test1 {
    $arr = "red", "green", "blue"
    $arr | ForEach-Object {
        Write-Output " * $_"
    }
}

Test
