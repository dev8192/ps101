
function Test1 {
    $colors = "red", "green", "blue"
    foreach ($color in $colors) {
        Write-Output " - $color"
    }
}

function Test1 {
    $colors = "red", "green", "blue"
    $colors | ForEach-Object {
        Write-Output " -- $_"
    }
}

function Test {
    $colors = "red", "green", "blue"
    for ($i = 0; $i -lt $colors.count; $i++) {
        Write-Output " --- $($colors[$i])"
    }
}

Test
