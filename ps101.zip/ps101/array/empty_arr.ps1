
function Test {
    $arr = @()
    $arr.Count
    $arr = @("apple")
    $arr.Count
}

Test
