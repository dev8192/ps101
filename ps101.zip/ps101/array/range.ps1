function Test {
    $nums = 1..5
    $nums
    "$nums"
}

Test
