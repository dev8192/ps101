function Test {
    $colors = @("Red", "Green", "Blue")
    $colors -join ' - '
}

function Test {
    $colors = "Red - Green - Blue"
    $colors -split ' - '
}

Test
