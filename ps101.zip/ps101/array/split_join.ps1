function Test {
    $colors = @("Red", "Green", "Blue")
    $colors -join ' - '
}

Test
