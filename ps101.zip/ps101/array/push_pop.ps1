
function Test {
    $arr = 1, 2, 3
    "$arr"

    $arr += 4
    "$arr"

    $arr += 5, 6
    "$arr"
}

# TODO: what about pop()?

Test

