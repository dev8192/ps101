function test {
    $array = @(1, 2) + @(5, 10)
    $array.count
    "$array"
}

test
