<#
What is the difference between
    $arr1 = 'abc'.ToCharArray()
    $arr2 = @('a', 'b', 'c')
#>