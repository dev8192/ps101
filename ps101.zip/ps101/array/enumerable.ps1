
function test {
    $arr = 1, 2, 3
    $arr -is [System.Collections.IEnumerable]

    $str = 'hello'
    $str -is [System.Collections.IEnumerable]

    $num = 444
    $num -is [System.Collections.IEnumerable]
}

test
