function Test {
    $arr = 1, 2, 3, 4, 5
    $arr = $arr | Where-Object { $_ -ne 3 }
    "$arr"
}

Test
