function Test {
    $arr = @(1, 2, 2, 3, 4, 4, 4, 5)
    $unique = $arr | Sort-Object -Unique
    "$unique"
}

function Test {
    $list = "Apple", "Banana", "Apple", "Orange", "Banana"
    $list | Sort-Object -Unique
}

function Test {
    $arr = @(1, 2, 2, 3, 4, 4, 4, 5)
    $uniqueSet = New-Object System.Collections.Generic.HashSet[object]
    foreach ($item in $arr) {
        # $null = $uniqueSet.Add($item)
        $uniqueSet.Add($item) | Out-Null
    }
    "$uniqueSet"
    $result = [object[]]($uniqueSet)
    "$result"
}

Test
