
function Test {
    $list1 = New-Object System.Collections.Generic.List[int]
    $list1.GetType().Name # List`1

    $list2 = New-Object System.Collections.Generic.List[int]
    $list2.GetType().Name # List`1
}

Test
