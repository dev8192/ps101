function test {
    Write-Host "--- Services: Status (Desc), then Name (Asc) ---"
    # Status: Running (4) > Stopped (1). Descending puts Running first.
    Get-Service | 
    Sort-Object -Property `
    @{Expression="Status"; Descending=$true}, `
    @{Expression="DisplayName"; Ascending=$true} | 
    Select-Object -First 10
}

test
