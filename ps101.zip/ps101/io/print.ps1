
function Test1 {
    Write-Output "example 1"
    Write-Host "example 2"
    Write-Warning "example 3"
}

# writeHost({msg: 'hello', foregroundColor: 'Red'})
function Test1 {
    Write-Host "hello"
    Write-Host "hello" -ForegroundColor Red
    Write-Host "hello" -ForegroundColor Green
    Write-Host "hello" -ForegroundColor Blue
}

function Test {
    # Write-Output "hello" -ForegroundColor Red
    Write-Host "hello" -ForegroundColor Red
}

Test
