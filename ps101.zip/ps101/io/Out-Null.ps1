function Test {
    "start"
    "not printed" | Out-Null
    "end"
}

Test
