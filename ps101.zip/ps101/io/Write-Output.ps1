<#
what is the difference between:
Write-Output something
Write-Output (something)

The parentheses only matter 
when you need to force PowerShell to evaluate an expression first.
#>
function Test1 {
    Write-Output Get-Location
    Write-Output (Get-Location)
}

function Test1 {
    Write-Output 123
    Write-Output (123)
}

# hello : The term 'hello' is not recognized as the name of a cmdlet
function Test1 {
    Write-Output hello
    Write-Output (hello)
}

function Test1 {
    $var1 = 333
    Write-Output $var1
    Write-Output ($var1)
}

function Test1 {
    Write-Output 1 + 2
    Write-Output (1 + 2)
}

function Test {
    Write-Output (Get-Date)
    Write-Output Get-Date
}

Test
