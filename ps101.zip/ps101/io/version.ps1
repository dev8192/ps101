function Test {
    $PSVersionTable.PSVersion
}

function Test1 {
    $name = "PowerShell"
    $version = $PSVersionTable.PSVersion

    Write-Output "Hello from $name!"
    Write-Output "Running version: $version"
}

Test
