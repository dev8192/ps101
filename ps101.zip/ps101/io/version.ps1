function Test {
    $PSVersionTable.PSVersion
}

Test
