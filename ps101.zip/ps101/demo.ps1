<#
    learning-demo.ps1
    A collection of small functions that demonstrate core PowerShell concepts.
    Designed for developers coming from JavaScript/Node.js.
#>

# -------------------------------
# 1. Variables & Basic Output
# -------------------------------
function Show-Basics {
    $name = "PowerShell"
    $version = $PSVersionTable.PSVersion

    Write-Output "Hello from $name!"
    Write-Output "Running version: $version"
}

# -------------------------------
# 2. Arrays & Hashtables
# -------------------------------
function Show-Collections {
    $arr = 1, 2, 3, 4
    $map = @{
        language = "PowerShell"
        type     = "Scripting"
        cool     = $true
    }

    Write-Output "Array:"
    $arr

    Write-Output "`nHashtable:"
    $map
}

# -------------------------------
# 3. Pipeline & Filtering
# -------------------------------
function Show-Pipeline {
    # Equivalent to: processes.filter(p => p.cpu > 100).map(p => p.name)
    Get-Process |
        Where-Object { $_.CPU -gt 100 } |
        Select-Object -Property Name, CPU
}



# -------------------------------
# 5. Working with Files
# -------------------------------
function Show-FileDemo {
    $path = ".\demo.txt"

    "Hello from PowerShell!" | Set-Content $path
    Write-Output "File written: $path"

    $content = Get-Content $path
    Write-Output "File content:"
    Write-Output $content
}

# -------------------------------
# 6. Calling REST APIs
# -------------------------------
function Call-Api {
    param(
        [string]$Url = "https://api.github.com/repos/PowerShell/PowerShell"
    )

    $response = Invoke-RestMethod -Uri $Url -Headers @{ "User-Agent" = "PS-Demo" }
    return $response | Select-Object name, stargazers_count, forks_count
}

# -------------------------------
# 7. Objects & Custom Output
# -------------------------------
function Make-CustomObject {
    $obj = [PSCustomObject]@{
        Id      = 1
        Message = "Hello"
        Time    = (Get-Date)
    }

    return $obj
}

# -------------------------------
# 8. Error Handling
# -------------------------------
function Show-ErrorHandling {
    try {
        Get-Item "C:\this\path\does\not\exist.txt" -ErrorAction Stop
    }
    catch {
        Write-Warning "Something went wrong:"
        Write-Warning $_.Exception.Message
    }
}

# -------------------------------
# 9. Modules (Importing)
# -------------------------------
function Show-ModuleInfo {
    Get-Module -ListAvailable |
        Select-Object Name, Version |
        Sort-Object Name
}

# -------------------------------
# 10. Script Entry Point
# -------------------------------
function Run-All {
    Show-Basics
    Show-Collections
    Show-Pipeline
    Write-Output "2 + 3 = $(Add-Numbers 2 3)"
    Show-FileDemo
    Call-Api
    Make-CustomObject
    Show-ErrorHandling
    Show-ModuleInfo
}
