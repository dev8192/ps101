class Server {
    [string]$Host
    [int]$Port
    Server([string]$Hostname, [int]$port) {
        $this.Host = $Hostname
        $this.Port = $port
    }
    [string] Connect() {
        return "Connecting to $($this.Hostname):$($this.Port)"
    }
}

$srv = [Server]::new("localhost", 8080)
$srv.Connect()
