
function Test {
    class Person {
        [string]$Name
        [int]$Age
    }
    $p = [Person]::new()
    $p.Name = "Alice"
    $p.Age  = 30
    $p
}

function Test {
    class Person {
        [string]$Name
        [int]$Age
        Person([string]$name, [int]$age) {
            $this.Name = $name
            $this.Age  = $age
        }
    }
    $p = [Person]::new("Bob", 25)
    $p
}


# ------------------------------------------------------------
# 3. Class with Methods
# ------------------------------------------------------------
function Demo-Methods {
    class Calculator {
        [int] Add([int]$a, [int]$b) {
            return $a + $b
        }
    }

    $calc = [Calculator]::new()
    $calc.Add(5, 7)
}


# ------------------------------------------------------------
# 4. Class with Static Members
# ------------------------------------------------------------
function Demo-StaticMembers {
    class MathUtil {
        static [int] Multiply([int]$a, [int]$b) {
            return $a * $b
        }
    }

    [MathUtil]::Multiply(6, 7)
}


# ------------------------------------------------------------
# 5. Inheritance
# ------------------------------------------------------------
function Demo-Inheritance {
    class Animal {
        [string]$Name

        [string] Speak() {
            return "Some generic sound"
        }
    }

    class Dog : Animal {
        [string] Speak() {
            return "Woof!"
        }
    }

    $d = [Dog]::new()
    $d.Name = "Rex"
    $d.Speak()
}


# ------------------------------------------------------------
# 6. Method Overriding
# ------------------------------------------------------------
function Demo-MethodOverride {
    class Base {
        [string] Describe() { return "Base class" }
    }

    class Derived : Base {
        [string] Describe() { return "Derived class" }
    }

    [Derived]::new().Describe()
}


# ------------------------------------------------------------
# 7. Properties with Get/Set Logic
# ------------------------------------------------------------
# function Demo-PropertyGetSet {
#     class Counter {
#         hidden [int]$value = 0

#         Counter() {}

#         [int] Value {
#             get { return $this.value }
#             set {
#                 if ($value -lt 0) { throw "Value cannot be negative" }
#                 $this.value = $value
#             }
#         }
#     }

#     $c = [Counter]::new()
#     $c.Value = 10
#     $c.Value
# }


# ------------------------------------------------------------
# 8. Using Enums in Classes
# ------------------------------------------------------------
function Demo-EnumUsage {
    enum Status {
        Started
        Running
        Finished
    }

    class Job {
        [Status]$State

        Job() {
            $this.State = [Status]::Started
        }
    }

    $j = [Job]::new()
    $j.State
}


# ------------------------------------------------------------
# 9. Class with Hidden/Internal Methods
# ------------------------------------------------------------
function Demo-HiddenMethods {
    class Secret {
        hidden [string] HiddenMethod() {
            return "You shouldn't see this"
        }

        [string] PublicMethod() {
            return "Public method called"
        }
    }

    $s = [Secret]::new()
    $s.PublicMethod()
}


# ------------------------------------------------------------
# 10. Using Classes to Model Real Objects
# ------------------------------------------------------------
function Demo-RealWorldModel {
    class Server {
        [string]$Host
        [int]$Port

        Server([string]$host, [int]$port) {
            $this.Host = $host
            $this.Port = $port
        }

        [string] Connect() {
            return "Connecting to $($this.Host):$($this.Port)"
        }
    }

    $srv = [Server]::new("localhost", 8080)
    $srv.Connect()
}


# ------------------------------------------------------------
# 11. Class with Static Fields (Shared State)
# ------------------------------------------------------------
function Demo-StaticFields {
    class Counter {
        static [int]$Total = 0

        Counter() {
            [Counter]::Total++
        }
    }

    [Counter]::new() | Out-Null
    [Counter]::new() | Out-Null
    [Counter]::new() | Out-Null

    [Counter]::Total
}


# ------------------------------------------------------------
# 12. Class with Overloaded Constructors
# ------------------------------------------------------------
function Demo-ConstructorOverload {
    class Point {
        [int]$X
        [int]$Y

        Point() {
            $this.X = 0
            $this.Y = 0
        }

        Point([int]$x, [int]$y) {
            $this.X = $x
            $this.Y = $y
        }
    }

    $p1 = [Point]::new()
    $p2 = [Point]::new(5, 10)

    $p1, $p2
}

Test
