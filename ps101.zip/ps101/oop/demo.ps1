
# ------------------------------------------------------------
# 7. Properties with Get/Set Logic
# ------------------------------------------------------------
# function Demo-PropertyGetSet {
#     class Counter {
#         hidden [int]$value = 0

#         Counter() {}

#         [int] Value {
#             get { return $this.value }
#             set {
#                 if ($value -lt 0) { throw "Value cannot be negative" }
#                 $this.value = $value
#             }
#         }
#     }

#     $c = [Counter]::new()
#     $c.Value = 10
#     $c.Value
# }



# ------------------------------------------------------------
# 11. Class with Static Fields (Shared State)
# ------------------------------------------------------------
function Demo-StaticFields {
    class Counter {
        static [int]$Total = 0

        Counter() {
            [Counter]::Total++
        }
    }

    [Counter]::new() | Out-Null
    [Counter]::new() | Out-Null
    [Counter]::new() | Out-Null

    [Counter]::Total
}


# ------------------------------------------------------------
# 12. Class with Overloaded Constructors
# ------------------------------------------------------------
function Demo-ConstructorOverload {
    class Point {
        [int]$X
        [int]$Y

        Point() {
            $this.X = 0
            $this.Y = 0
        }

        Point([int]$x, [int]$y) {
            $this.X = $x
            $this.Y = $y
        }
    }

    $p1 = [Point]::new()
    $p2 = [Point]::new(5, 10)

    $p1, $p2
}

Test
