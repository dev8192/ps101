class Person {
    [string]$Name
    [int]$Age
    Person([string]$name, [int]$age) {
        $this.Name = $name
        $this.Age = $age
    }
    Add([int]$num) {
        $this.Age += $num
    }
}
$p = [Person]::new("Bob", 25)
$p

$p.Add(5)
$p

$p.Name = 'Alice'
$p
