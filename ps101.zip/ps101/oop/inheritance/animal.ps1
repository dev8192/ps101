class Animal {
    [string]$Name
    [string] Speak() {
        return "Some generic sound"
    }
}

class Dog : Animal {
    [string] Speak() {
        return "Woof!"
    }
}

$d = [Dog]::new()
$d.Name = "Rex"
$d.Speak()
