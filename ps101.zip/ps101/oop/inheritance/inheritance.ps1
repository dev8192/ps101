class Base {
    [string] Describe() { return "Base class" }
}

class Derived : Base {
    [string] Describe() { return "Derived class" }
}

[Derived]::new().Describe()
