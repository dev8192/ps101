
function Test1 {
    class Person {
        [string]$Name = 'Alice'
    }
    [Person]::new()
}

function Test {
    class Person {
        [string]$Name = 'Bob'
    }
    [Person]::new()
}

Test

this prints Bob