class Animal {
    [string]$Name
}

$obj = [Animal]::new()
$obj.Name = "Tiger"
$obj
