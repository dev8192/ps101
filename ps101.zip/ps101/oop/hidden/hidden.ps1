class Secret {
    hidden HiddenMethod() {
        Write-Host "Hidden method called"
    }
    PublicMethod() {
        Write-Host "Public method called"
        $this.HiddenMethod()
    }
}

$obj = [Secret]::new()
$obj.PublicMethod()
$obj.HiddenMethod() # this should not work, but it works!
