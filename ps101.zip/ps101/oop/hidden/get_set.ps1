<#
$c.value is available outside the class definition.
what does it mean to be 'hidden' then?
#>

class Counter {
    hidden [int]$value = 0
    [int] GetValue() { 
        return $this.value 
    }
    [void] SetValue([int]$v) {
        if ($v -lt 0) { throw "Value cannot be negative" }
        $this.value = $v
    }
}

$c = [Counter]::new()
$c.SetValue(10)
$c.GetValue()
$c.value
