class Example {}
$p = [Example]::new()
# $p.str = 'one'
# $p['str'] = 'one'
$p
