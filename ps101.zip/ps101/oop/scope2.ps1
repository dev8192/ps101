
function Test {
    class Person {
        [string]$Name
        [int]$Age
    }
}

$p = [Person]::new()
$p.Name = "Alice"
$p.Age  = 30
$p