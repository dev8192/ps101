class Point {
    [int]$X
    [int]$Y
    Point() {
        $this.X = 0
        $this.Y = 0
    }
    Point([int]$x, [int]$y) {
        $this.X = $x
        $this.Y = $y
    }
}

$p1 = [Point]::new()
$p2 = [Point]::new(5, 10)

$p1, $p2
