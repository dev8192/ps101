<#
static class members persist for the lifetime of the session

When i run this script,
3, 6, 9, 12, etc are printed.
How do i force [Counter]::Total to start at 0 on each run?
#>

class Counter {
    static [int]$Total = 0
    Counter() {
        [Counter]::Total++
    }
}

[Counter]::new() | Out-Null
[Counter]::new() | Out-Null
[Counter]::new() | Out-Null

[Counter]::Total
