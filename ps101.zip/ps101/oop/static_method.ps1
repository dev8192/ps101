class MathUtil {
    # static [int] Multiply([int]$a, [int]$b) {
    #     return $a * $b
    # }
    static [int] Multiply($a, $b) {
        return $a * $b
    }
}

[MathUtil]::Multiply(5, 6)
