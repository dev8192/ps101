class Counter {
    [ValidateRange(0, [int]::MaxValue)]
    [int]$Value = 0
}

$c = [Counter]::new()
$c.Value = 10  # Works
# $c.Value = -1 # Throws a "ValueRange" validation error automatically
$c.Value
