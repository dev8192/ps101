function test {
    $hash = @{ Name = "Vasya"; City = "Moscow" }
    $hash
    '-' * 30
    # $hash["Age"] = 30
    $hash.Age = 30
    $hash   
    '-' * 30
    $hash.Remove("City")
    $hash
}

test
