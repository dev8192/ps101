function test() {
    const map = new Map([
        ['one', 111],
        ['two', 222],
        ['three', 333],
    ])
    for (const key of map.keys()) {
        console.log(key)
    }
    console.log('-'.repeat(30))
    for (const val of map.values()) {
        console.log(val)
    }
    console.log('-'.repeat(30))
    for (const [key, val] of map.entries()) {
        console.log(key, val)
    }
}

test()
