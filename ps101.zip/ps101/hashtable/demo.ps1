
function Test1 {
    $obj = [PSCustomObject]@{
        Name = "Alice"
        Age  = 30
    }
    $obj.GetType().Name

    $hash = @{
        Name = "Alice"
        Age  = 30
    }   
    $hash.GetType().Name
}


function Test1 {
    $obj = [PSCustomObject]@{ Name = "Bob"; Age = 40 }
    $hash = @{ Name = "Alice"; Age = 30 }

    $obj.Name
    $obj.Age
    # $obj['Age']

    $hash.Name
    $hash['Age']
}

function Test1 {
    $obj = [PSCustomObject]@{
        First  = 1
        Second = 2
        Third  = 3
    }
    $obj | Format-List

    $hash = @{
        First  = 1
        Second = 2
        Third  = 3
    }
    $hash | Format-List
}

function Test1 {
    $obj = [PSCustomObject]@{
        Name = "Alice"
        Age  = 30
    }
    $obj | Format-Table

    $hash = @{
        Name = "Alice"
        Age  = 30
    }
    $hash | Format-Table
}

function Test1 {
    $obj = [PSCustomObject]@{ Name = "Alice" }
    $hash = @{ Name = "Alice" }

    $obj | Add-Member -NotePropertyName "Age" -NotePropertyValue 30
    $hash["Age"] = 30

    "$obj"
    $hash
}

function Test1 {
    $obj = [PSCustomObject]@{ Name = "Alice" }
    $hash = @{ Name = "Alice" }

    $obj.Name = "Bob"
    $hash["Name"] = "Bob"

    $hash.Remove("Name")

    "Object after modification: $obj"
    "Hashtable after removal:   $hash"
}

function Test1 {
    $hash = @{
        Host = "localhost"
        Port = 8080
    }
    $hash.GetType().Name

    $obj = [PSCustomObject]$hash
    $obj.GetType().Name
}

function Test1 {
    $obj = [PSCustomObject]@{
        Process = "pwsh"
        PID     = 1234
        Status  = "Running"
    }
    $obj | Format-Table
}

function Test1 {
    $hash = @{
        apple  = "fruit"
        carrot = "vegetable"
        salmon = "fish"
    }
    $hash['carrot']
    $hash['car']
}

function Test1 {
    $hash = @{}
    foreach ($i in 1..3) {
        $hash["Key$i"] = "Value$i"
    }
    $hash
}

function Test {
    $hash = @{
        z = 1
        a = 2
        m = 3
    }
    $hash.GetEnumerator() | Sort-Object Name
}

Test
