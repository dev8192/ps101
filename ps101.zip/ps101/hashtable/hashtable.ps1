
function Test1 {
    $arr = 1, 2, 3, 4
    Write-Output "Array: $arr"
}

function Test1 {
    $map = @{
        language = "PowerShell"
        type     = "Scripting"
        cool     = $true
    }
    $map
}

function Test {
    $obj = [PSCustomObject]@{
    # $obj = @{
        Id      = 1
        Message = "Hello"
        Time    = (Get-Date)
    }
    return $obj
}

function Test {
    $person = @{
        Name = "Alex"
        Age = 30
        City = "Moscow"
    }
    Write-Host "HashTable:" -ForegroundColor Yellow
    $person | Format-Table -AutoSize
    Write-Host "  Type: $($person.GetType().Name)" -ForegroundColor Cyan
    Write-Host ""
}

Test
