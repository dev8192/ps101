
function Test {
    $map = @{
        language = "PowerShell"
        type     = "Scripting"
        cool     = $true
    }
    $map
}

function Test {
    $person = @{
        Name = "Alex"
        Age = 30
        City = "Moscow"
    }
    # $person.GetType().Name
    # $person | Format-Table -AutoSize
    $person | Format-Table
}

Test
