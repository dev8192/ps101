$map = @{
# $map = [ordered]@{
    'one'   = 111
    'two'   = 222
    'three' = 333
}

function test1 {
    foreach ($key in $map.Keys) {
        Write-Host $key
    }
    Write-Host ('-' * 30)
    foreach ($val in $map.Values) {
        Write-Host $val
    }
    Write-Host ('-' * 30)
    foreach ($entry in $map.GetEnumerator()) {
        Write-Host $entry.Key $entry.Value
    }
}

function test {
    $map.Keys.GetType()
    $map.Values.GetType()
    $map.GetEnumerator().GetType()

    $map.GetEnumerator.GetType()
    "$($map.GetEnumerator.GetType().BaseType)"
}

test
