function Test {
    Clear-Host
}

Test
