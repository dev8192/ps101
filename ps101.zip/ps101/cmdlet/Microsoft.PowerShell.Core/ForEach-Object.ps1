# addition
function Test {
    @(10, 20, 30) | ForEach-Object { $_ + 1 }
}

# string concatenation
function Test {
    @('a', 'b', 'c') | ForEach-Object { $_ + 1 }
}

Test
