function Test {
    # Get-Module
    Get-Module -ListAvailable
}

function Test1 {
    Get-Module -ListAvailable |
        Select-Object Name, Version |
        Sort-Object Name
}

Test
