
function Test {
    param(
        [string]$Url = "https://api.github.com/repos/PowerShell/PowerShell"
    )

    $response = Invoke-RestMethod -Uri $Url -Headers @{ "User-Agent" = "PS-Demo" }
    # return $response | Select-Object name, stargazers_count, forks_count
    return $response
}

Test
