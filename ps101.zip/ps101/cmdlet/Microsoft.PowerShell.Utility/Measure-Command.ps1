function Test {
    $items = 1..10000
    $time1 = Measure-Command {
        foreach ($item in $items) {
            $result = $item * 2
        }
    }
    Write-Host "ForEach: $($time1.TotalMilliseconds) ms"
}

Test
