function Test1 {
    'start'
    Start-Sleep -Seconds 3
    'end'
}

function Test {
    for ($i = 0; $i -lt 5; $i++) {
        Write-Output "for: $i"
        Start-Sleep -Seconds 1
    }
}

Test
