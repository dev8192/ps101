function Test {
    Get-Service
}

function Test1 {
    $services = Get-Service | Select-Object -First 5
    foreach ($service in $services) {
        Write-Host "Service: $($service.Name) - Status: $($service.Status)"
    }
}

Test
