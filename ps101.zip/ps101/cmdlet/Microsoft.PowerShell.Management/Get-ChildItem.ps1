function Test1 {
    # Get-ChildItem
    Get-ChildItem -Recurse
}

function Test {
    $files = Get-ChildItem -Filter "*.txt"
    foreach ($file in $files) {
        Write-Host "Processing: $($file.Name)"
    }
}

Test
