
function Test1 {
    Get-Process
}

function Test {
    Get-Process explorer
    # Get-Process explorer | Format-List *
}

function Test1 {
    Get-Process |
        Where-Object { $_.CPU -gt 100 } |
        Select-Object -Property Name, CPU
}

Test
