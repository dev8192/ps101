<#
https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management
https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/get-childitem
#>

function Test {
    # Get-ChildItem
    Get-ChildItem -Recurse
}

Test
