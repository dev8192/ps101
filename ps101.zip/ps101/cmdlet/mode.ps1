<#
l (link)
r (read-only)
h (hidden)
s (system)

d-----  directory
-a----  archive
------
------
------
------
#>