<#
    get-date-demo.ps1
    A complete demonstration of Get-Date and common date/time operations.
#>

function Test1 {
    Write-Output (Get-Date)
}

function Test1 {
    $now = Get-Date
    Write-Output ("{0}" -f $now.ToShortDateString())
    Write-Output ("{0}" -f $now.ToLongDateString())
    Write-Output ("{0}" -f $now.ToString("yyyy-MM-dd"))
    Write-Output ("{0}" -f $now.ToString("HH:mm:ss"))
    Write-Output ("{0}" -f $now.ToString("yyyy-MM-ddTHH:mm:ss"))
}

function Test {
    $now = Get-Date
    Write-Output "Year:      $($now.Year)"
    Write-Output "Month:     $($now.Month)"
    Write-Output "Day:       $($now.Day)"
    Write-Output "Hour:      $($now.Hour)"
    Write-Output "Minute:    $($now.Minute)"
    Write-Output "Second:    $($now.Second)"
    Write-Output "DayOfWeek: $($now.DayOfWeek)"
}

function Test {
    $now = Get-Date
    Write-Output "Now:              $now"
    Write-Output "Add 1 day:        $($now.AddDays(1))"
    Write-Output "Subtract 2 hours: $($now.AddHours(-2))"
    Write-Output "Add 30 minutes:   $($now.AddMinutes(30))"
    Write-Output "Add 1 month:      $($now.AddMonths(1))"
}

function Test1 {
    $date = Get-Date
    Write-Output "$date"

    $date = Get-Date "1990-05-12"
    Write-Output "$date"

    $date = Get-Date -Year 2025 -Month 12 -Day 31 -Hour 23 -Minute 59
    Write-Output "$date"
}

function Test {
    $date = Get-Date
    Write-Output "$date"
    Write-Output $date.ToString()
    Write-Output $date.ToString("yyyy-MM-dd HH:mm:ss")
    Write-Output $date
}

function Show-DateComparison {
    $a = Get-Date "2024-01-01"
    $b = Get-Date "2024-06-01"

    Write-Output "A < B: $($a -lt $b)"
    Write-Output "A > B: $($a -gt $b)"
    Write-Output "A == B: $($a -eq $b)"
}

function Show-StopwatchDemo {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    Start-Sleep -Milliseconds 500
    $sw.Stop()
    Write-Output "Elapsed milliseconds: $($sw.ElapsedMilliseconds)"
}

function Show-UnixTimestamp {
    $now = Get-Date
    $unix = [int][double]::Parse((Get-Date -UFormat %s))

    $fromUnix = [DateTimeOffset]::FromUnixTimeSeconds($unix).DateTime

    Write-Output "`nUnix timestamps:"
    Write-Output "Now:            $now"
    Write-Output "Unix timestamp: $unix"
    Write-Output "Back to date:   $fromUnix"
}

function Show-TimeZones {
    Write-Output "`nAvailable time zones (first 5):"
    Get-TimeZone -ListAvailable | Select-Object -First 5 | Format-Table Id, DisplayName

    Write-Output "`nConvert time zone:"
    $utc = Get-Date
    $pst = $utc.ToUniversalTime().AddHours(-8)

    Write-Output "UTC: $utc"
    Write-Output "PST (manual example): $pst"
}

Test
