function Test {
    $StartDate = (Get-Date "2026-02-10")
    $EndDate = (Get-Date "2026-02-11")
    # $EndDate = (Get-Date "2026-02-15")
    $TimeSpan = New-TimeSpan -Start $StartDate -End $EndDate
    $TimeSpan
}

function Test {
    $TimeSpan = New-TimeSpan -Hours 1 -Minutes 25
    $TimeSpan
}

Test
