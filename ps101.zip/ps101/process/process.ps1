<#
how do i get the total number of processes of chrome and vs code?
#>

function test {
    Get-Process
}

function test {
    (Get-Process).Count
}

function test {
    Get-Process | measure
    # Get-Process | Measure-Object
    # Get-Process | Measure-Object | Select-Object -ExpandProperty Count
}

function test {
    # (Get-Process -Name "chrome").Count
    # Get-Process -Name "chrome"
    Get-Process -Name "code"
}

function test {
    Get-Process chrome, code -ErrorAction SilentlyContinue |
        Group-Object Name |
        Select-Object Name, Count
}

function test1 {
    Get-Process | 
        Sort-Object -Property `
        @{Expression="ProcessName"; Descending=$false}, `
        # @{Expression="Id"; Descending=$false} | 
        @{Expression="Id"; Descending=$true} | 
        Select-Object -First 12
}

test