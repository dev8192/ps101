function test {
    Get-Process | 
        Where-Object { 
            [string]::IsNullOrWhiteSpace($_.Description) 
        } | 
        Sort-Object WorkingSet -Descending | 
        Format-Table Id, Name, @{Name="MemoryMB"; Expression={[math]::Round($_.WorkingSet / 1MB)}}
}

test
