function test {
    [Math]::PI
    [Math]::PI -eq 3.14159265358979
    [Math]::PI -eq 3.141592653589793
}

test
