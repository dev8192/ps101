function test() {
    console.log(Math.PI === 3.14159265358979) // false
    console.log(Math.PI === 3.141592653589793) // true
}

test()
