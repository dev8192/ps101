

function Test {
    $base = 5
    $exponent = 2
    [Math]::Pow($base, $exponent)
}

function Test {
    $number = 16
    [Math]::Pow($number, 0.5)
    [Math]::Sqrt($number)
}

function Test {
    [bigint]$largeBase = 10
    $exponent = 50
    [System.Numerics.BigInteger]::Pow($largeBase, $exponent)
}

Test
