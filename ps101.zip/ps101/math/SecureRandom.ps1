function Get-SecureRandom {
    param(
        [int]$Length = 16
    )
    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
    $bytes = New-Object byte[] $Length
    $rng.GetBytes($bytes)    
    $secureRandom = [System.BitConverter]::ToString($bytes).Replace('-', '')    
    $rng.Dispose()
    return $secureRandom
}

Get-SecureRandom
