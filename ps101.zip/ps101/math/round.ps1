# Banker's Rounding
function test {
    [Math]::Round(11.5) # 12
    [Math]::Round(12.5) # 12
    [Math]::Round(13.5) # 14
    [Math]::Round(14.5) # 14
    [Math]::Round(15.5) # 16
    [Math]::Round(16.5) # 16
}

function test {
    $mode = [MidpointRounding]::AwayFromZero
    [Math]::Round(11.5, $mode) # 12
    [Math]::Round(12.5, $mode) # 13
    [Math]::Round(13.5, $mode) # 14
    [Math]::Round(14.5, $mode) # 15
    [Math]::Round(15.5, $mode) # 16
    [Math]::Round(16.5, $mode) # 17
}

function test {
    [Math]::Floor(16.5)
    [Math]::Ceiling(16.5)
}

function test {
    [Math]::PI
    $precision = 2
    $rounded = [Math]::Round([Math]::PI, $precision)
    $rounded
    $rounded.GetType()
}

test
