


# ==============================================================================
# FUNCTION 5: Seeded Random (Reproducible Results)
# ==============================================================================
function Get-RandomSeeded {
    <#
    .SYNOPSIS
        Generates reproducible random numbers using a seed
    .DESCRIPTION
        Same seed produces same sequence of random numbers
    #>
    $seed = 12345
    
    Write-Host "Using Seed: $seed" -ForegroundColor Gray
    Write-Host "First run:" -ForegroundColor White
    
    $random1 = Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed
    Write-Host "  Random Number 1: $random1" -ForegroundColor Cyan
    
    $random2 = Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed
    Write-Host "  Random Number 2 (same seed): $random2" -ForegroundColor Cyan
    
    Write-Host "`nNote: Same seed = Same results (useful for testing)" -ForegroundColor DarkGray
    return @($random1, $random2)
}

# ==============================================================================
# FUNCTION 6: Random Boolean (Coin Flip)
# ==============================================================================
function Get-RandomBoolean {
    <#
    .SYNOPSIS
        Generates a random boolean value
    .DESCRIPTION
        Useful for yes/no, true/false, coin flip scenarios
    #>
    $result = Get-Random -InputObject @($true, $false)
    $displayText = if ($result) { "Heads (True)" } else { "Tails (False)" }
    Write-Host "Coin Flip Result: $displayText" -ForegroundColor $(if ($result) { "Green" } else { "Red" })
    return $result
}

# ==============================================================================
# FUNCTION 7: Random String/Password Generation
# ==============================================================================
function Get-RandomString {
    <#
    .SYNOPSIS
        Generates a random alphanumeric string
    .DESCRIPTION
        Useful for passwords, tokens, or unique identifiers
    #>
    param(
        [int]$Length = 12
    )
    
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%'
    $password = -join ((Get-Random -InputObject $chars.ToCharArray() -Count $Length))
    
    Write-Host "Random String ($Length chars): $password" -ForegroundColor Yellow
    return $password
}

# ==============================================================================
# FUNCTION 8: Random Date Generation
# ==============================================================================
function Get-RandomDate {
    <#
    .SYNOPSIS
        Generates a random date within a range
    .DESCRIPTION
        Combines random numbers with DateTime objects
    #>
    param(
        [DateTime]$StartDate = (Get-Date "2023-01-01"),
        [DateTime]$EndDate = (Get-Date "2024-12-31")
    )
    
    $timeSpan = New-TimeSpan -Start $StartDate -End $EndDate
    $randomDays = Get-Random -Minimum 0 -Maximum $timeSpan.Days
    $randomDate = $StartDate.AddDays($randomDays)
    
    Write-Host "Date Range: $($StartDate.ToShortDateString()) to $($EndDate.ToShortDateString())" -ForegroundColor Gray
    Write-Host "Random Date: $($randomDate.ToLongDateString())" -ForegroundColor Magenta
    return $randomDate
}

# ==============================================================================
# FUNCTION 9: Random Without Replacement (Unique Values)
# ==============================================================================
function Get-RandomUnique {
    <#
    .SYNOPSIS
        Generates unique random numbers (no duplicates)
    .DESCRIPTION
        Ensures each number appears only once
    #>
    param(
        [int]$Count = 5,
        [int]$Min = 1,
        [int]$Max = 10
    )
    
    if ($Count -gt ($Max - $Min + 1)) {
        Write-Host "Error: Cannot get $Count unique numbers from range $($Min)-$($Max)" -ForegroundColor Red
        return $null
    }
    
    $uniqueNumbers = Get-Random -InputObject ($Min..$Max) -Count $Count
    Write-Host "$Count Unique Random Numbers ($Min-$Max): $($uniqueNumbers -join ', ')" -ForegroundColor Green
    return $uniqueNumbers
}

# ==============================================================================
# FUNCTION 10: Cryptographic Random (Secure)
# ==============================================================================
function Get-SecureRandom {
    <#
    .SYNOPSIS
        Generates cryptographically secure random numbers
    .DESCRIPTION
        Uses .NET RNGCryptoServiceProvider for security-sensitive scenarios
    #>
    param(
        [int]$Length = 16
    )
    
    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
    $bytes = New-Object byte[] $Length
    $rng.GetBytes($bytes)
    
    # Convert to hex string
    $secureRandom = [System.BitConverter]::ToString($bytes).Replace('-', '')
    
    Write-Host "Secure Random Hex ($Length bytes): $secureRandom" -ForegroundColor Red
    Write-Host "Note: Use for passwords, tokens, encryption keys" -ForegroundColor DarkGray
    
    $rng.Dispose()
    return $secureRandom
}

# ==============================================================================
# FUNCTION 11: Random with Weighted Probability
# ==============================================================================
function Get-RandomWeighted {
    <#
    .SYNOPSIS
        Selects random item with weighted probability
    .DESCRIPTION
        Some items have higher chance of being selected
    #>
    $items = @(
        @{ Name = "Common"; Weight = 70; Color = "Green" },
        @{ Name = "Uncommon"; Weight = 20; Color = "Blue" },
        @{ Name = "Rare"; Weight = 8; Color = "Purple" },
        @{ Name = "Legendary"; Weight = 2; Color = "Orange" }
    )
    
    # Create weighted array
    $weightedPool = @()
    foreach ($item in $items) {
        1..$item.Weight | ForEach-Object { $weightedPool += $item }
    }
    
    $selected = Get-Random -InputObject $weightedPool
    Write-Host "Weighted Random Selection:" -ForegroundColor White
    Write-Host "  Result: $($selected.Name)" -ForegroundColor $selected.Color
    Write-Host "  Probability: $($selected.Weight)%" -ForegroundColor Gray
    return $selected.Name
}

# ==============================================================================
# FUNCTION 12: Random Dice Roll Simulation
# ==============================================================================
function Get-RandomDice {
    <#
    .SYNOPSIS
        Simulates rolling dice
    .DESCRIPTION
        Useful for games, simulations, and decision making
    #>
    param(
        [int]$NumberOfDice = 2,
        [int]$Sides = 6
    )
    
    $rolls = @()
    1..$NumberOfDice | ForEach-Object {
        $rolls += Get-Random -Minimum 1 -Maximum ($Sides + 1)
    }
    
    $total = ($rolls | Measure-Object -Sum).Sum
    Write-Host "Rolling $NumberOfDice d$Sides : $($rolls -join ', ')" -ForegroundColor Cyan
    Write-Host "Total: $total" -ForegroundColor Yellow
    return @{ Rolls = $rolls; Total = $total }
}

# ==============================================================================
# FUNCTION 13: Random Percentage
# ==============================================================================
function Get-RandomPercentage {
    <#
    .SYNOPSIS
        Generates a random percentage value
    .DESCRIPTION
        Useful for progress simulation, probability displays
    #>
    $percentage = Get-Random -Minimum 0 -Maximum 101
    $bar = "#" * ($percentage / 5)
    Write-Host "Random Percentage: $percentage%" -ForegroundColor Magenta
    Write-Host "[$bar$('-' * (20 - $bar.Length))]" -ForegroundColor DarkGray
    return $percentage
}

# ==============================================================================
# FUNCTION 14: Random IP Address
# ==============================================================================
function Get-RandomIP {
    <#
    .SYNOPSIS
        Generates a random IP address
    .DESCRIPTION
        Useful for testing network configurations
    #>
    $octets = @()
    1..4 | ForEach-Object {
        $octets += Get-Random -Minimum 1 -Maximum 255
    }
    
    $ipAddress = $octets -join '.'
    Write-Host "Random IP Address: $ipAddress" -ForegroundColor Blue
    return $ipAddress
}

# ==============================================================================
# FUNCTION 15: Random GUID/UUID
# ==============================================================================
function Get-RandomGUID {
    <#
    .SYNOPSIS
        Generates a random GUID
    .DESCRIPTION
        Uses .NET Guid class for unique identifiers
    #>
    $guid = [Guid]::NewGuid()
    Write-Host "Random GUID: $guid" -ForegroundColor DarkCyan
    return $guid
}

# ==============================================================================
# MAIN DEMO EXECUTION
# ==============================================================================
function Invoke-RandomDemo {
    <#
    .SYNOPSIS
        Runs all random number demonstrations
    #>
    
    Clear-Host
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  PowerShell Random Number Demo" -ForegroundColor Cyan
    Write-Host "========================================`n" -ForegroundColor Cyan
    
    Write-Host "Press Enter to continue through each demo..." -ForegroundColor DarkGray
    Write-Host ""
    
    # Demo 1
    Read-Host "1. Basic Random Number"
    Get-RandomBasic
    Write-Host ""
    
    # Demo 2
    Read-Host "2. Random in Range (1-100)"
    Get-RandomInRange -Min 1 -Max 100
    Write-Host ""
    
    # Demo 3
    Read-Host "3. Random from Array"
    Get-RandomFromArray
    Write-Host ""
    
    # Demo 4
    Read-Host "4. Multiple Random Samples"
    Get-RandomMultipleSamples
    Write-Host ""
    
    # Demo 5
    Read-Host "5. Seeded Random (Reproducible)"
    Get-RandomSeeded
    Write-Host ""
    
    # Demo 6
    Read-Host "6. Random Boolean (Coin Flip)"
    Get-RandomBoolean
    Write-Host ""
    
    # Demo 7
    Read-Host "7. Random String/Password"
    Get-RandomString -Length 16
    Write-Host ""
    
    # Demo 8
    Read-Host "8. Random Date"
    Get-RandomDate
    Write-Host ""
    
    # Demo 9
    Read-Host "9. Random Unique Values"
    Get-RandomUnique -Count 5 -Min 1 -Max 10
    Write-Host ""
    
    # Demo 10
    Read-Host "10. Cryptographic Secure Random"
    Get-SecureRandom -Length 16
    Write-Host ""
    
    # Demo 11
    Read-Host "11. Weighted Random Selection"
    Get-RandomWeighted
    Write-Host ""
    
    # Demo 12
    Read-Host "12. Dice Roll Simulation"
    Get-RandomDice -NumberOfDice 3 -Sides 6
    Write-Host ""
    
    # Demo 13
    Read-Host "13. Random Percentage"
    Get-RandomPercentage
    Write-Host ""
    
    # Demo 14
    Read-Host "14. Random IP Address"
    Get-RandomIP
    Write-Host ""
    
    # Demo 15
    Read-Host "15. Random GUID"
    Get-RandomGUID
    Write-Host ""
    
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Demo Complete!" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
}

# ==============================================================================
# RUN DEMO (Uncomment to execute)
# ==============================================================================
# Invoke-RandomDemo

# ==============================================================================
# QUICK REFERENCE
# ==============================================================================
<#
QUICK USAGE EXAMPLES:

# Basic random number
Get-Random

# Random between 1 and 100
Get-Random -Minimum 1 -Maximum 101

# Random from array
Get-Random -InputObject @("A", "B", "C")

# Multiple unique samples
Get-Random -InputObject (1..50) -Count 5

# Seeded (reproducible)
Get-Random -SetSeed 12345

# Secure cryptographic random
$rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()

# Random GUID
[Guid]::NewGuid()
#>