function Get-RandomWeighted {
    $items = @(
        @{ Name = "Common"; Weight = 70; Color = "Green" },
        @{ Name = "Uncommon"; Weight = 20; Color = "Blue" },
        @{ Name = "Rare"; Weight = 8; Color = "Purple" },
        @{ Name = "Legendary"; Weight = 2; Color = "Orange" }
    )
    $weightedPool = @()
    foreach ($item in $items) {
        1..$item.Weight | ForEach-Object { $weightedPool += $item }
    }
    $selected = Get-Random -InputObject $weightedPool
    Write-Host "Weighted Random Selection:" -ForegroundColor White
    Write-Host "  Result: $($selected.Name)" -ForegroundColor $selected.Color
    Write-Host "  Probability: $($selected.Weight)%" -ForegroundColor Gray
    return $selected.Name
}

Get-RandomWeighted
