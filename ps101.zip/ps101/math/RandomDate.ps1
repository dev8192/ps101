function Get-RandomDate {
    param(
        [DateTime]$StartDate = (Get-Date "2026-02-10"),
        [DateTime]$EndDate = (Get-Date "2026-02-20")
    )    
    $timeSpan = New-TimeSpan -Start $StartDate -End $EndDate
    $randomDays = Get-Random -Minimum 0 -Maximum $timeSpan.Days
    $randomDate = $StartDate.AddDays($randomDays)
    return $randomDate
}

Get-RandomDate
