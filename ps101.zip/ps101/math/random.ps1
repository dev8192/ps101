# Microsoft.PowerShell.Utility
function Test {
    Get-Random
}

function Test {
    $Min = 1
    $Max = 10
    Get-Random -Minimum $Min -Maximum $Max
}

function Test {
    $colors = @("Red", "Green", "Blue", "Yellow", "Purple", "Orange")
    Get-Random -InputObject $colors
}

function Test {
    $numbers = 1..20
    "$(Get-Random -InputObject $numbers -Count 5)"
    "$(Get-Random -InputObject $numbers -Count 5)"
    "$(Get-Random -InputObject $numbers -Count 5)"
}

function Test {
    $seed = 12345    
    "$(Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed)"
    "$(Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed)"    
    "$(Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed)"
}

function Test {
    function Get-RandomString {
        $Length = 12
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%'
        $password = -join ((Get-Random -InputObject $chars.ToCharArray() -Count $Length))
        return $password
    }
    Get-RandomString
    Get-RandomString
}

# Random IP
function Test {
    $octets = @()
    1..4 | ForEach-Object {
        $octets += Get-Random -Minimum 1 -Maximum 255
    }
    $ipAddress = $octets -join '.'
    $ipAddress
}

function Test {
    $guid = [Guid]::NewGuid()
    "$guid"
    $guid = [Guid]::NewGuid()
    "$guid"
    $guid = [Guid]::NewGuid()
    "$guid"
}

function Test1 {

}

function Test1 {

}

function Test1 {

}

Test
