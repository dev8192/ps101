# Microsoft.PowerShell.Utility
function Test {
    Get-Random
}

function Test {
    $Min = 1
    $Max = 10
    Get-Random -Minimum $Min -Maximum $Max
}

function Test {
    $colors = @("Red", "Green", "Blue", "Yellow", "Purple", "Orange")
    Get-Random -InputObject $colors
}

function Test {
    $numbers = 1..20
    "$(Get-Random -InputObject $numbers -Count 5)"
    "$(Get-Random -InputObject $numbers -Count 5)"
    "$(Get-Random -InputObject $numbers -Count 5)"
}

function Test {
    $seed = 12345    
    "$(Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed)"
    "$(Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed)"    
    "$(Get-Random -Minimum 1 -Maximum 100 -SetSeed $seed)"
}

function Test1 {

}

function Test1 {

}

function Test1 {

}

Test
