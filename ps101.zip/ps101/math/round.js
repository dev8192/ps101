function test1() {
    console.log(Math.round(11.5)) // 12
    console.log(Math.round(12.5)) // 13
    console.log(Math.round(13.5)) // 14
    console.log(Math.round(14.5)) // 15
    console.log(Math.round(15.5)) // 16
    console.log(Math.round(16.5)) // 17
}

function test() {
    console.log(Math.floor(16.5)) // 16
    console.log(Math.ceil(16.5)) // 17
}

function test() {
    console.log(Math.PI)
    console.log(Math.PI.toFixed(2))
    console.log(typeof Math.PI.toFixed(2))
    console.log(Number(Math.PI.toFixed(2)))
    console.log(parseFloat(Math.PI.toFixed(2)))
}

test()
