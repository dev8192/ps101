function Test1 {
    [Math]::Min(5, 10)
    [Math]::Min(15, 10)
}

function Test {
    [Math]::Max(5, 10)
    [Math]::Max(15, 10)
}

function Test1 {
    $users = @("user1", "user2", "user3", "user4", "user5")
    $batchSize = 2
    for ($i = 0; $i -lt $users.Count; $i += $batchSize) {
        $batch = $users[$i..([Math]::Min($i + $batchSize - 1, $users.Count - 1))]
        Write-Host "Processing batch: $($batch -join ', ')"
    }
}

Test
