<#
why is 'iniside catch' not printed??
#>

# Set-StrictMode -Version 2.0

# Non-Terminating Error
function Test {
    try {
        Write-Host $hello
        'before catch'
    } catch { 
        'inside catch'
    }
    'after catch'
}

# Terminating Error
function Test1 {
    try {
        hello-world
        'before catch'
    } catch { 
        'inside catch'
    }
    'after catch'
}

Test
