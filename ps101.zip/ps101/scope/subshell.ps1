<#
you created $global:GlobalVar
later on you write $global:GlobalVar and GlobalVar
why is this inconsistency?
#>
$global:GlobalVar = "I am GLOBAL (defined in script)"
$script:ScriptVar = "I am SCRIPT (defined in script)"

Write-Host "Inside script:"
Write-Host "  GlobalVar = $GlobalVar"
Write-Host "  ScriptVar = $ScriptVar"

function Test-Scope {
    Write-Host "`n=== INSIDE FUNCTION ==="

    Write-Host "GlobalVar (visible): $GlobalVar"
    Write-Host "ScriptVar (visible): $ScriptVar"

    Write-Host "`nModifying both inside function..."

    $global:GlobalVar = "GLOBAL changed inside function"
    $script:ScriptVar = "SCRIPT changed inside function"

    Write-Host "GlobalVar (after change): $GlobalVar"
    Write-Host "ScriptVar (after change): $ScriptVar"
}

Test-Scope


# ================================
#   OUTSIDE FUNCTION AGAIN
# ================================

Write-Host "`n=== BACK IN SCRIPT ==="

Write-Host "GlobalVar (after function): $GlobalVar"
Write-Host "ScriptVar (after function): $ScriptVar"

powershell -NoLogo -Command {
    Write-Host "`nInside subshell:"
    Write-Host "GlobalVar = $GlobalVar"
    Write-Host "ScriptVar = $ScriptVar"
}
