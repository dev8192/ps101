
function Outer-Func {
    $private:PrivateVar = 444
    $Var = 555
    function Inner-Func {
        $private:PrivateVar
        $Var
    }
    Inner-Func
}

Outer-Func
