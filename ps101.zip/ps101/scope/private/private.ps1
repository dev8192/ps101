$private:PrivateVar = 444
$Var = 333

function Func {
    $private:PrivateVar
    $Var
}

Func
