Set-StrictMode -Version 2.0

$global:GlobalVar = 333
$script:ScriptVar = 444
Write-Host "GlobalVar: $GlobalVar"
Write-Host "ScriptVar: $ScriptVar"

function Test-Scope {
    $LocalVar = 555
    $private:PrivateVar = 222
    $global:GlobalVar += 7
    $script:ScriptVar += 6

    Write-Host "LocalVar: $LocalVar"
    Write-Host "PrivateVar: $PrivateVar"
    Write-Host "GlobalVar: $GlobalVar"
    Write-Host "ScriptVar: $ScriptVar"
}

Test-Scope

Write-Host "GlobalVar: $GlobalVar"
Write-Host "ScriptVar: $ScriptVar"

try { 
    Write-Host $LocalVar
} catch { 
    Write-Host "LocalVar is NOT visible outside the function" 
}

try { 
    Write-Host $PrivateVar 
} catch { 
    Write-Host "PrivateVar is NOT visible outside the function" 
}

"done"
