# they seem identical
$LocalVar = 111
$global:GlobalVar = 222
$script:ScriptVar = 333
$private:PrivateVar = 444

$LocalVar
$global:GlobalVar
$script:ScriptVar
$private:PrivateVar
