$global:Example = "I am global"

function Test {
    $Example = "I am local"
    Write-Host "$Example"
    Write-Host "$global:Example"
}

Write-Host "$Example"

Test
