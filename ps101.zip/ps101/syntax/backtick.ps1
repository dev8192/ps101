# TODO: find a simpler example
function Test {
    $inputString = "powershell"
    $outputString = $inputString -replace "^p", "P" `
                                 -replace "shell$", "Shell"
    Write-Host $outputString
}

Test
