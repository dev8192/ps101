function Test {
    # $Host
    "$Host"
}

function Test {
    # $Pid
    "$Pid"
}

function Test1 {
    # $Home
    "$Home"
}

function Test1 {
    # $Error
    "$Error"
}

Test
