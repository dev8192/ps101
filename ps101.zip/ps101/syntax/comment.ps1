<#
PS C:\ps101> .\syntax\comment.ps1
PS C:\ps101> powershell .\syntax\comment.ps1
#>

# $name = "world"
$name = "there"
Write-Output "hello $name"
