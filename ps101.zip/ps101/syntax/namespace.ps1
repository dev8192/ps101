using namespace System.Runtime.CompilerServices

$arr = 1, 2, 3
$id = [RuntimeHelpers]::GetHashCode($arr)
Write-Output "Array ID: $id"
