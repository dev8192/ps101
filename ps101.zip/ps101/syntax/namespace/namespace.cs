namespace Version1 {
    public class Hello {
        public static string Say() {
            return "Hello 111";
        }
    } 
}

namespace Version2 {
    public class Hello {
        public static string Say() {
            return "Hello 222";
        }
    } 
}
