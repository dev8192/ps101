<#
./syntax/namespace/namespace.ps1
#>
function Test {
    Add-Type -Path "syntax/namespace/namespace.cs"
    [Version1.Hello]::Say()
    [Version2.Hello]::Say()
}

<#
cd syntax/namespace
./namespace.ps1
#>
function Test1 {
    Add-Type -Path "namespace.cs"
    [Version1.Hello]::Say()
    [Version2.Hello]::Say()
}

Test
