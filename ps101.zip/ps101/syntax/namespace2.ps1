# not to be confused with an actual namespace

$Runtime = [System.Runtime.CompilerServices.RuntimeHelpers]

$arr = 1, 2, 3
$id = $Runtime::GetHashCode($arr)
Write-Output "Array ID: $id"
