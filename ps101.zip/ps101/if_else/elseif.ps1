function Print-Score {
    param($score)
    if ($score -ge 90) {
        Write-Host "Grade: A (Excellent)" -ForegroundColor Green
    } elseif ($score -ge 80) {
        Write-Host "Grade: B (Good)" -ForegroundColor Green
    } elseif ($score -ge 70) {
        Write-Host "Grade: C (Average)" -ForegroundColor DarkYellow
    } else {
        Write-Host "Grade: F (Needs Improvement)" -ForegroundColor Red
    }
}

Print-Score 95
Print-Score 85
Print-Score 75
Print-Score 65
