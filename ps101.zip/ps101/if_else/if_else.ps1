<#

#>

function Test {
    $result = $true
    # $result = $false
    if ($result) {
        'Green'
    } else {
        'Red'
    }
}

function Test1 {
    # $result = $true
    $result = $false
    "$(if ($result) { 'Green' } else { 'Red' })"
}

function Test {
    $result = $true
    # $result = $false
    Write-Host "hello" -ForegroundColor $(if ($result) { "Green" } else { "Red" })
}


Test
