function Test {
    for ($i = 0; $i -lt 10; $i++) {
        if ($i % 2 -ne 0) {
            Write-Host "$i" -ForegroundColor Red
        } else {
            Write-Host "$i" -ForegroundColor Green
        }
    }
}

Test
