function Test1 {
    $status = "Running"
    switch ($status) {
        "Running" { Write-Host "Service is Up" -ForegroundColor Green }
        "Stopped" { Write-Host "Service is Down" -ForegroundColor Red }
        "Paused"  { Write-Host "Service is Paused" -ForegroundColor DarkYellow }
    }
}

function Test1 {
    $fileName = "archive_2023.log"
    switch -Wildcard ($fileName) {
        "*.log"   { Write-Host "This is a log file" -ForegroundColor Blue }
        "*.txt"   { Write-Host "This is a text file" -ForegroundColor Blue }
        "*.bak"   { Write-Host "This is a backup file" -ForegroundColor Blue }
        default   { Write-Host "Unknown file type" -ForegroundColor Gray }
    }
}

function Test {
    $inputCode = "ERR-503"
    switch -Regex ($inputCode) {
        "^ERR-\d{3}$" { Write-Host "Valid Error Code Format" -ForegroundColor Magenta }
        "^WARN.*"     { Write-Host "This is a Warning" -ForegroundColor DarkYellow }
        default       { Write-Host "Invalid Code Format" -ForegroundColor Red }
    }
}

function Test {
    $number = 42
    switch ($number) {
        { $_ -lt 0 }      { Write-Host "Negative Number" -ForegroundColor Red }
        { $_ -eq 0 }      { Write-Host "Zero" -ForegroundColor Gray }
        { $_ -gt 0 -and $_ -lt 50 } { Write-Host "Positive and less than 50" -ForegroundColor Green }
        { $_ -ge 50 }     { Write-Host "Positive and 50 or greater" -ForegroundColor Cyan }
    }
}

Test
