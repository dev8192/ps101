Write-Host "exiting..."
Start-Sleep -Seconds 3
exit