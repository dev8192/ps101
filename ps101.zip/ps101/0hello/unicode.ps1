<#
Save with Encoding --> utf8bom
#>

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
"привет мир"