function Test {
    Write-Host "My PID is $PID"
    Start-Sleep -Seconds 20
}

function Test {
    Write-Host "My PID is $([System.Diagnostics.Process]::GetCurrentProcess().Id)"
}

function Test {
    [System.Diagnostics.Process]::GetCurrentProcess()
}

Test
