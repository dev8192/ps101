function Test {
    Write-Host "My PID is $PID"
    # Start-Sleep -Seconds 20
}

function Test1 {
    Write-Host "My pid is $([System.Diagnostics.Process]::GetCurrentProcess().Id)"
}

function Test1 {
    [System.Diagnostics.Process]::GetCurrentProcess()
}

Test
