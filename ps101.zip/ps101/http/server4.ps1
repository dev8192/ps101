<#
Ctrl+C works only after the page refresh
#>

$port = 8080
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()
Write-Host "Server started at http://localhost:$port/" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop." -ForegroundColor Cyan

# Flag for graceful shutdown
$script:running = $true

# Register Ctrl+C handler
[Console]::TreatControlCAsInput = $true

try {
    while ($running -and $listener.IsListening) {
        # Check for Ctrl+C manually (non-blocking)
        if ([Console]::KeyAvailable) {
            $key = [Console]::ReadKey($true)
            if ($key.Key -eq 'C' -and $key.Modifiers -eq 'Control') {
                Write-Host "`n🛑 Shutdown requested..." -ForegroundColor Yellow
                $script:running = $false
                break
            }
        }

        # Start async context retrieval
        $contextTask = $listener.GetContextAsync()
        
        # Wait with timeout AND check shutdown flag
        while (-not $contextTask.IsCompleted -and $running) {
            Start-Sleep -Milliseconds 100
        }
        
        if (-not $running) { break }
        
        # Get the context (now safe since task is complete)
        $context = $contextTask.GetAwaiter().GetResult()
        $request = $context.Request
        $response = $context.Response

        Write-Host "$($request.HttpMethod): $($request.Url)"
        
        $content = "<h1>Hello from PowerShell!</h1>"
        $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
        $response.ContentLength64 = $buffer.Length
        $response.OutputStream.Write($buffer, 0, $buffer.Length)
        $response.Close()
    }
}
catch [System.Management.Automation.PipelineStoppedException] {
    # Catch PowerShell's Ctrl+C exception
    Write-Host "`n🛑 Pipeline stopped" -ForegroundColor Yellow
}
catch [Exception] {
    # Catch all other exceptions
    Write-Host "❌ Error: $_" -ForegroundColor Red
}
finally {
    Write-Host "🧹 Cleaning up..." -ForegroundColor Gray
    $listener.Stop()
    $listener.Close()
    $script:running = $false
}

Write-Host "✅ Server stopped. Done." -ForegroundColor Green