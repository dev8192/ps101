<#
Not working
#>
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:8080/")
$listener.Start()

Write-Host "Server running at http://localhost:8080/"
Write-Host "Press Ctrl+C to stop."

$callback = {
    param($result)

    if (-not $listener.IsListening) { return }

    $context = $listener.EndGetContext($result)

    $response = $context.Response
    $content  = "Hello from PowerShell!`n" +
                "You requested: $($context.Request.Url.AbsolutePath)"
    $buffer   = [System.Text.Encoding]::UTF8.GetBytes($content)

    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
    $response.OutputStream.Close()

    # Queue next request
    $listener.BeginGetContext($callback, $null) | Out-Null
}

# Start async loop
$listener.BeginGetContext($callback, $null) | Out-Null

try {
    while ($listener.IsListening) {
        Start-Sleep -Milliseconds 200
    }
}
finally {
    $listener.Stop()
    Write-Host "Server stopped."
}
