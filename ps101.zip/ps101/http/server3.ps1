<#
Working!
#>
$port = 8080
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")

try {
    $listener.Start()
    Write-Host "Server started at http://localhost:$port/" -ForegroundColor Green
    Write-Host "Press Ctrl+C to stop."

    while ($listener.IsListening) {
        # Check for a pending request asynchronously to keep the loop responsive to Ctrl+C
        $contextTask = $listener.GetContextAsync()
        
        # Wait in short increments so PowerShell can process the interrupt signal
        while (-not $contextTask.AsyncWaitHandle.WaitOne(200)) { }

        $context = $contextTask.GetAwaiter().GetResult()
        $request = $context.Request
        $response = $context.Response

        Write-Host "Received $($request.HttpMethod) request for $($request.Url)"

        # Simple HTML response
        $buffer = [System.Text.Encoding]::UTF8.GetBytes("<html><body><h1>Hello from PowerShell!</h1></body></html>")
        $response.ContentLength64 = $buffer.Length
        $response.OutputStream.Write($buffer, 0, $buffer.Length)
        $response.Close()
    }
}
catch {
    Write-Host "`nStopping server..." -ForegroundColor Yellow
}
finally {
    $listener.Stop()
    $listener.Close()
}
