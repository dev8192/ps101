<#
Working!



#>
$port = 8080
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()
Write-Host "Server started at http://localhost:$port/" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop."

try {
while ($listener.IsListening) {
    $contextTask = $listener.GetContextAsync()
    
    while (-not $contextTask.AsyncWaitHandle.WaitOne(200)) { }

    $context = $contextTask.GetAwaiter().GetResult()
    $request = $context.Request
    $response = $context.Response

    Write-Host "$($request.HttpMethod): $($request.Url)"
    # Write-Host "$($request.HttpMethod): $($request.Url.AbsolutePath)"

    $content = "<h1>Hello from PowerShell!</h1>"
    $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
    $response.Close()
}
} catch [System.Management.Automation.PipelineStoppedException] {
    Write-Host "Caught Ctrl+C (PipelineStoppedException)" -ForegroundColor Cyan
} catch {
    Write-Host "Error: $($_.Exception.Message)"
} finally {
Write-Host "Ctrl+C was pressed"
$listener.Stop()
$listener.Close()
}
Write-Host "done"

why neither Write-Host "error" nor Write-Host "done" are printed?
