<#
Ctrl+C not working
#>
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:8080/")
$listener.Start()

Write-Host "Server running at http://localhost:8080/"
Write-Host "Press Ctrl+C to stop."

while ($listener.IsListening) {
    "loop"
    $context = $listener.GetContext()
    $request  = $context.Request
    $response = $context.Response

    $content = "Hello from PowerShell local server!`n" +
                "You requested: $($request.Url.AbsolutePath)"
    $buffer  = [System.Text.Encoding]::UTF8.GetBytes($content)

    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
    $response.OutputStream.Close()
}
