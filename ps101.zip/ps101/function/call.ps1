<#
PowerShell supports named parameters and positional parameters.
#>

function test {
    function func($first, $second) {
        "$first $second"
    }
    func 'hello' 'world'
    func -first 'hello' -second 'world'
    func -second 'world' -first 'hello'
}

function test {
    function func($first = 'hello', $second = 'world') {
        "$first $second"
    }
    func
    func 'hi'
    func -second 'there'
    func 'hi' 'there'
}

test
