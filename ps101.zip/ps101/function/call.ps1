
function func {
    param($first, $second)
    "$first $second"
}

func 'hello' 'world'
func -first 'hello' -second 'world'
func -second 'world' -first 'hello'
