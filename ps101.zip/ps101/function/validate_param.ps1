
function Test {
    function DefaultValidateSet {
        param(
            [ValidateSet("Low", "Medium", "High")]
            [string]$Level = "Medium"
        )
        "Selected level: $Level"
    }
    DefaultValidateSet 'Low'
    # DefaultValidateSet 'hello'
    DefaultValidateSet
}

function Test {
    function DefaultValidateRange {
        param(
            [ValidateRange(1, 10)]
            [int]$Rating = 5
        )
        "Rating: $Rating"
    }
    DefaultValidateRange 3
    DefaultValidateRange
    # DefaultValidateRange 33
}

Test
