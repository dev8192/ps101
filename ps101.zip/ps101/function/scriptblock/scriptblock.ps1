
function Test {
    $sb = { "Hello from a scriptblock" }
    & $sb
    # $sb
    # "$sb"
}

function Test {
    $sb = {
        param($name)
        "Hello, $name"
    }
    & $sb "Alice"
    & $sb "Bob"
}

<#
TODO: What is the difference between a function and a scriptblock in ps1?
#>
function Test {
    $sb = {
        param($value)
        "$prefix $value"
    }
    function Func {
        param($value)
        "$prefix $value"
    }
    $prefix = "Result:"
    & $sb 222
    Func 333
}

function Test {
    function Invoke-Callback {
        param([ScriptBlock]$Callback)
        "Before callback"
        & $Callback
        "After callback"
    }
    Invoke-Callback { "Inside callback" }
}

Test
