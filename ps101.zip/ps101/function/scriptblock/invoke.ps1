
function test {
    $sb = { param($a, $b) $a * $b }
    $sb.Invoke(5, 4)
    & $sb 5 6
}

function test {
    Invoke-Command -ScriptBlock { "Running inside Invoke-Command" }
}

function test {
    $sb = { "Running inside Invoke-Command!" }
    Invoke-Command -ScriptBlock $sb
}

test
