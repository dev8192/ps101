function test {
    # $code = "param(`$x) `$x * 10"
    $code = 'param($x) $x * 10'
    $sb = [ScriptBlock]::Create($code)
    & $sb 4
}

test
