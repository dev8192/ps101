
function test() {
    function Invoke-Func($p1, $p2, $p3) {
        $PSBoundParameters.GetType().Name
        $args.GetType().Name
    }
    Invoke-Func 123 'hello' $true
}

<############################## $args ##############################>

function test1 {
    function func {
        # Write-Host ($args -join ' ')
        "$args"
        # $args.count
    }
    func
    func 'hello'
    func 'hello' 'world'
    func 'hello' 123 $true
}

function test1 {
    function func {
        "$args"
        $args.GetType()
    }
    func 'hello' 'world'
}

<############################## PSBoundParameters ##############################>

function test1() {
    function Invoke-Func($p1, $p2, $p3) {
        $PSBoundParameters
        '----------'
    }
    Invoke-Func
    Invoke-Func 123
    Invoke-Func 123 'hello'
    Invoke-Func 123 'hello' $true
}

test
