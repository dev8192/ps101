
function test {
    function func {
        # Write-Host ($args -join ' ')
        "$args"
        # $args.count
    }
    func
    func 'hello'
    func 'hello' 'world'
    func 'hello' 123 $true
}

function test1 {
    function func {
        "$args"
        $args.GetType()
    }
    func 'hello' 'world'
}

test
