
function Test {
    function BasicDefaultParameter {
        param(
            [string]$Name = "World"
        )
        "Hello, $Name"
    }
    BasicDefaultParameter 'Alice'
    BasicDefaultParameter
}

function Test {
    function DefaultExpression {
        param(
            [datetime]$Timestamp = (Get-Date)
        )
        "Timestamp: $Timestamp"
    }
    DefaultExpression
}

function Test {
    function DefaultNumber {
        param(
            [int]$RandomNumber = $(Get-Random -Minimum 1 -Maximum 100)
        )
        "Generated number: $RandomNumber"
    }
    DefaultNumber 333
    DefaultNumber
    DefaultNumber
}


function Test {
    function DefaultObject {
        param(
            $Config = @{
                Host = "localhost"
                Port = 8080
            }
        )
        $Config.GetType().Name
        "Connecting to $($Config.Host):$($Config.Port)"
    }
    DefaultObject @{
        Host = "example.com"
        Port = 80
    }
    DefaultObject
}

Test
