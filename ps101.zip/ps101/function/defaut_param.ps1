
function test1 {
    function BasicDefaultParameter {
        param(
            [string]$Name = "World"
        )
        "Hello, $Name"
    }
    BasicDefaultParameter 'Alice'
    BasicDefaultParameter
}

function test1 {
    function func {
        param(
            [datetime]$Timestamp = (Get-Date)
        )
        "Timestamp: $Timestamp"
    }
    function func($Timestamp = (Get-Date)) {
        "Timestamp: $Timestamp"
    }
    func
    Start-Sleep -Seconds 3
    func
}

function test1 {
    function DefaultNumber {
        param(
            [int]$RandomNumber = $(Get-Random -Minimum 1 -Maximum 100)
        )
        "Generated number: $RandomNumber"
    }
    DefaultNumber 333
    DefaultNumber
    DefaultNumber
}


function test1 {
    function DefaultObject {
        param(
            $Config = @{
                Host = "localhost"
                Port = 8080
            }
        )
        $Config.GetType().Name
        "Connecting to $($Config.Host):$($Config.Port)"
    }
    DefaultObject @{
        Host = "example.com"
        Port = 80
    }
    DefaultObject
}

function test1 {
    function CircleArea([double]$Radius = 1.0) {
        $Area = [Math]::PI * [Math]::Pow($Radius, 2)
        return $Area
    }
    CircleArea
    CircleArea -Radius 5.5
}

function test() {
    function Invoke-Func($Param) {
        if (-not $PSBoundParameters.ContainsKey('Param')) {
            $Param = 123
        }
        Write-Host $Param
    }
    Invoke-Func
    Invoke-Func 456
}

test
