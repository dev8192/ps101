<#
    PowerShell Inner Functions & Closures Demo
    Each example is isolated in its own function.
#>

function Test {
    function Outer {
        function Inner {
            "Inner function executed"
        }
        "Outer function executed"
        Inner
    }
    Outer
    # Inner
}

function Test1 {
    function Outer {
        $message = "Hello from outer scope"
        function Inner {
            "Inner sees: $message"
        }
        Inner
    }
    Outer
}

function Test {
    function Outer {
        $counter = 0
        function Increment {
            $script:counter = $counter + 1
            $counter = $script:counter
        }
        Increment
        Increment
        "Final counter value: $counter"
    }

    Outer
}

function Test {
    function Outer {
        $prefix = "Value:"
        function Inner {
            param($x)
            "$prefix $x"
        }
        return (Get-Command Inner)
    }
    $f = Outer
    & $f 42
}

function Test {
    function Make-Counter {
        $count = 0

        function Increment {
            $script:count = $count + 1
            $count = $script:count
        }

        return (Get-Command Increment)
    }

    $c1 = Make-Counter
    $c2 = Make-Counter

    & $c1
    & $c1
    & $c2

    "Counter 1: $(& $c1)"
    "Counter 2: $(& $c2)"
}

function Test {
    function Outer {
        function Multiply {
            param($a, $b)
            $a * $b
        }
        Multiply 6 7
    }
    Outer
}

# scriptblock
function Test {
    function Outer {
        $factor = 10

        $sb = {
            param($x)
            $x * $factor
        }

        return $sb
    }

    $multiply = Outer
    & $multiply 5
}

function Test {
    function Create-Accumulator {
        $sum = 0

        $sb = {
            param($x)
            $script:sum = $sum + $x
            $sum = $script:sum
        }

        return $sb
    }

    $acc = Create-Accumulator
    & $acc 5
    & $acc 10
    & $acc 3
}

Test
