function test() {
    function func() {
        console.log(arguments)
    }
    func()
    func('hello')
    func('hello', 'world')
}

test()
