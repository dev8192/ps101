# no closure
function test {
    function add {
        param($n, $x)
        return $x + $n
    }
    add 5 10
    add 5 11
    add 5 12
}

# no closure (2)
function test {
    function add5 {
        param($x)
        return $x + 5
    }
    add5 20
    add5 21
    add5 22
}

function test1 {
    function Make-Adder {
        param($n)
        return {
            param($x)
            $x + $n
        }.GetNewClosure()
    }
    $add5 = Make-Adder 5
    & $add5 10
    & $add5 11
    & $add5 12
}

test
