
function Test {
    $sb = { "Hello from a scriptblock" }
    & $sb
    # $sb
}

function Test {
    $sb = {
        param($name)
        "Hello, $name"
    }
    & $sb "Alice"
}

<#
What is the difference between a function and a scriptblock in ps1?
#>
function Test {
    $prefix = "Result:"
    $sb = {
        param($value)
        "$prefix $value"
    }
    function Func {
        param($value)
        "$prefix $value"
    }
    & $sb 222
    Func 333
}

function Demo-PassScriptblockToFunction {
    function Invoke-Callback {
        param([ScriptBlock]$Callback)
        "Before callback"
        & $Callback
        "After callback"
    }

    Invoke-Callback { "Inside callback" }
}


# ------------------------------------------------------------
# 5. Returning Scriptblocks from Functions
# ------------------------------------------------------------
function Demo-ReturnScriptblock {
    function Make-Adder {
        param($n)

        return {
            param($x)
            $x + $n
        }
    }

    $add5 = Make-Adder 5
    & $add5 10
}


# ------------------------------------------------------------
# 6. Using Scriptblock.Invoke() Instead of &
# ------------------------------------------------------------
function Demo-ScriptblockInvokeMethod {
    $sb = { param($a, $b) $a * $b }
    $sb.Invoke(6, 7)
}


# ------------------------------------------------------------
# 7. Using Scriptblock.Create() to Build Scriptblocks Dynamically
# ------------------------------------------------------------
function Demo-ScriptblockCreate {
    $code = "param(`$x) `$x * 10"
    $sb = [ScriptBlock]::Create($code)

    & $sb 4
}


# ------------------------------------------------------------
# 8. Using Scriptblocks with ForEach-Object
# ------------------------------------------------------------
function Demo-ScriptblockPipeline {
    1..5 | ForEach-Object { $_ * 2 }
}


# ------------------------------------------------------------
# 9. Using Scriptblocks with Where-Object
# ------------------------------------------------------------
function Demo-ScriptblockFilter {
    1..10 | Where-Object { $_ -gt 5 }
}


# ------------------------------------------------------------
# 10. Scriptblock as a Stored Command (Reusable Logic)
# ------------------------------------------------------------
function Demo-ReusableScriptblock {
    $isEven = { param($n) $n % 2 -eq 0 }

    1..6 | ForEach-Object {
        if (& $isEven $_) {
            "$_ is even"
        } else {
            "$_ is odd"
        }
    }
}


# ------------------------------------------------------------
# 11. Scriptblock with GetNewClosure() (Captures Variables Safely)
# ------------------------------------------------------------
function Demo-GetNewClosure {
    $factor = 3

    $sb = {
        param($x)
        $x * $factor
    }.GetNewClosure()

    & $sb 7
}


# ------------------------------------------------------------
# 12. Using Scriptblocks for Delayed Execution
# ------------------------------------------------------------
function Demo-DelayedExecution {
    $task = { "Task executed at $(Get-Date)" }

    Start-Sleep -Seconds 1
    & $task
}


# ------------------------------------------------------------
# 13. Scriptblock as a Try/Catch Wrapper
# ------------------------------------------------------------
function Demo-ScriptblockTryCatch {
    function Safe-Invoke {
        param([ScriptBlock]$Action)

        try {
            & $Action
        }
        catch {
            "Error: $($_.Exception.Message)"
        }
    }

    Safe-Invoke { 1 / 0 }
}


# ------------------------------------------------------------
# 14. Using Scriptblocks with Invoke-Command (Local)
# ------------------------------------------------------------
function Demo-InvokeCommandLocal {
    Invoke-Command -ScriptBlock { "Running inside Invoke-Command" }
}


# ------------------------------------------------------------
# 15. Scriptblock with Begin/Process/End (Advanced Pipeline)
# ------------------------------------------------------------
function Demo-AdvancedPipelineScriptblock {
    $sb = {
        begin   { "Begin block" }
        process { "Processing $_" }
        end     { "End block" }
    }

    1..3 | & $sb
}

Test
