
function Test1 {
    function Print-Message {
        "Message 1"
    }
    Print-Message
}

function Test2 {
    function Print-Message {
        "Message 2"
    }
    Print-Message
}

Test1
Test2
