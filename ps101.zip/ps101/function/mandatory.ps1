
function Test {
    function DefaultWithMandatory {
        param(
            # [Parameter(Mandatory)]
            [string]$Name,
            [string]$Greeting = "Hello"
        )
        "$Greeting, $Name"
    }
    DefaultWithMandatory 'jack'
    DefaultWithMandatory
}

Test
