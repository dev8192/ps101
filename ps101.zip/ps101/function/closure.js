// no closure
function test1() {
    function add(n, x) {
        return x + n
    }
    console.log(add(5, 10))
    console.log(add(5, 11))
    console.log(add(5, 12))
}

// no closure (2)
function test1() {
    function add5(x) {
        return x + 5
    }
    console.log(add5(10))
    console.log(add5(11))
    console.log(add5(12))
}

function test() {
    function makeAdder(n) {
        // return (x) => x + n
        return function(x) {
            return x + n
        }
    }
    add5 = makeAdder(5)
    console.log(add5(10))
    console.log(add5(11))
    console.log(add5(12))
}

test()
