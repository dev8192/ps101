function Add-Numbers {
    param($a, $b)
    return $a + $b
}

function Add-Numbers1 {
    param(
        [int]$a,
        [int]$b
    )
    return $a + $b
}

# Add-Numbers 2 hello
Add-Numbers 2 3
