
function test() {
    function func(...args) {
        console.log(args)
    }
    func(5, 10, 15)
}

test()
