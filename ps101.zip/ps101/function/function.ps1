
function Test {
    function Add-Numbers {
        param($a, $b)
        # param(
        #     [int]$a,
        #     [int]$b
        # )
        '*** Add-Numbers ***'
        return $a + $b
    }
    # Add-Numbers 2 3
    # Add-Numbers 2 hello
    Add-Numbers 333
    Add-Numbers
}

function Test1 {
    function Add-Numbers($a = 5, $b = 10) {
        return $a + $b
    }
    Add-Numbers 2 3
    Add-Numbers 2
    Add-Numbers
}

Test
