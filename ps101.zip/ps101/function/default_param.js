function test() {
    function func(param) {
        if (param === undefined) {
            param = 123
        }
        console.log(param)
    }
    func()
    func(456)
}

test()
