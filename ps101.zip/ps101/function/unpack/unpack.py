
def test():
    def func(*args):
        print(len(args))
    arr = [5, 10, 15]
    func(arr)
    func(*arr)

test()
