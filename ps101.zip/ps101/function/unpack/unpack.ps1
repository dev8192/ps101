
function test {
    function func {
        $args.count
    }
    $arr = 5, 10, 15
    func $arr
    func @arr
}

test
