
function test() {
    function func() {
        console.log(arguments.length)
    }
    const arr = [5, 10, 15]
    func(arr)
    func(...arr)
}

test()
