function test {
    function func1($Name, $City) {
        Write-Host "Hello $Name from $City!"
    }
    function func2 {
        param($Name, $City)
        Write-Host "Hello $Name from $City!!"
    }
    func1 "Alice" "New York"
    func2 "Vasya" "Moscow"
}

function test1 {
    function Set-UserStatus {
        param (
            [Parameter(Mandatory=$true)]
            [string]$UserName,

            [Parameter(Mandatory=$false)]
            [string]$Status = "Active"
        )
        Write-Host "--- Mandatory Parameters ---"
        Write-Host "Setting $UserName to $Status."
    }
    Set-UserStatus -UserName "UserA"
}

function test1 {
    function Invoke-VerboseAction {
        param (
            [switch]$ShowDetails
        )
        Write-Host "--- Switch Parameters ---"
        if ($ShowDetails) {
            Write-Host "Detailed mode is ON. Performing extra logging..."
        } else {
            Write-Host "Running in standard mode."
        }
    }
    Invoke-VerboseAction -ShowDetails
}

function test1 {
    function Test-NetworkPort {
        [CmdletBinding()]
        param (
            [string]$ComputerName = "localhost",
            [int]$Port = 80
        )
        process {
            Write-Host "--- Advanced Function (CmdletBinding) ---"
            Write-Verbose "Attempting to connect to $ComputerName on port $Port..."
            # In a real script, you'd use Test-NetConnection here
            Write-Host "Task complete."
        }
    }
    Test-NetworkPort -ComputerName "127.0.0.1" -Verbose
}

function test1 {
    function Process-NameList {
        param (
            [Parameter(ValueFromPipeline=$true)]
            [string[]]$Names
        )
        process {
            foreach ($Name in $Names) {
                Write-Host "--- Pipeline Processing: $Name ---"
            }
        }
    }
    "John", "Jane", "Doe" | Process-NameList
}

test
