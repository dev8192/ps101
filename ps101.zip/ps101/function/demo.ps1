# 1. Basic Function: The simplest form of a function with no parameters.
function Invoke-SimpleGreeting {
    Write-Host "--- Basic Function ---"
    Write-Host "Hello! This is a simple, parameter-less function."
}

# 2. Positional Parameters: Accepts inputs based on their order without needing names.
function Invoke-PositionalParam ($Name, $City) {
    Write-Host "--- Positional Parameters ---"
    Write-Host "Hello $Name from $City!"
}

# 3. Typed & Default Parameters: Enforces data types and provides fallback values.
function Get-CircleArea {
    param (
        [double]$Radius = 1.0  # Default value is 1.0
    )
    Write-Host "--- Typed & Default Parameters ---"
    $Area = [Math]::PI * [Math]::Pow($Radius, 2)
    return $Area
}

# 4. Mandatory Parameters: Forces the user to provide a value (prompting if missing).
function Set-UserStatus {
    param (
        [Parameter(Mandatory=$true)]
        [string]$UserName,

        [Parameter(Mandatory=$false)]
        [string]$Status = "Active"
    )
    Write-Host "--- Mandatory Parameters ---"
    Write-Host "Setting $UserName to $Status."
}

# 5. Switch Parameters: Acting as a boolean flag (true if present, false if not).
function Invoke-VerboseAction {
    param (
        [switch]$ShowDetails
    )
    Write-Host "--- Switch Parameters ---"
    if ($ShowDetails) {
        Write-Host "Detailed mode is ON. Performing extra logging..."
    } else {
        Write-Host "Running in standard mode."
    }
}

# 6. Advanced Function (CmdletBinding): Adds standard cmdlet features like -Verbose.
function Test-NetworkPort {
    [CmdletBinding()]
    param (
        [string]$ComputerName = "localhost",
        [int]$Port = 80
    )
    process {
        Write-Host "--- Advanced Function (CmdletBinding) ---"
        Write-Verbose "Attempting to connect to $ComputerName on port $Port..."
        # In a real script, you'd use Test-NetConnection here
        Write-Host "Task complete."
    }
}

# 7. Pipeline Input: Allows the function to process objects passed via the '|' operator.
function Process-NameList {
    param (
        [Parameter(ValueFromPipeline=$true)]
        [string[]]$Names
    )
    process {
        foreach ($Name in $Names) {
            Write-Host "--- Pipeline Processing: $Name ---"
        }
    }
}

# --- Execution Examples ---

# Call Basic
Invoke-SimpleGreeting

# Call Positional (Order matters: Name then City)
Invoke-PositionalParam "Alice" "New York"

# Call Typed with Return Value
$MyArea = Get-CircleArea -Radius 5.5
Write-Host "Returned Area: $MyArea"

# Call Mandatory (Prompting will happen if you remove 'UserA')
Set-UserStatus -UserName "UserA"

# Call Switch
Invoke-VerboseAction -ShowDetails

# Call Advanced (Try adding -Verbose to see the hidden message)
Test-NetworkPort -ComputerName "127.0.0.1" -Verbose

# Call Pipeline
"John", "Jane", "Doe" | Process-NameList
