<#
    Working with Files
#>

function Test1 {
    Get-Content file.txt
}

function Test {
    $path = ".\demo.txt"
    $content = Get-Content $path
    Write-Output "File content:"
    Write-Output $content
}

Test
