function Test {
    Get-Content c_sharp/add_type_path/file15.cs | Format-Hex
}

Test
