
# New-Item -Path "test2" -ItemType "Directory"
New-Item -Path "test2" -ItemType "Directory" -Force
Set-Location -Path "test2"
# New-Item -Path "file1.txt" -ItemType "File"
New-Item -Path "file1.txt" -ItemType "File" -Force
'-' * 30
Get-Location
Set-Location -Path ".."
