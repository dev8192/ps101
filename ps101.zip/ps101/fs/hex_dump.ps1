function Dump-Hex {
    param([string]$Path)

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    "     00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F"
    ""

    for ($i = 0; $i -lt $bytes.Length; $i += 16) {
        $chunk = $bytes[$i..([Math]::Min($i+15, $bytes.Length-1))]
        $hex = ($chunk | ForEach-Object { "{0:X2}" -f $_ }) -join " "
        "{0:X8}  {1}" -f $i, $hex
    }
}

Dump-Hex example.txt
