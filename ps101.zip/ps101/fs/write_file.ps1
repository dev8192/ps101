
function Test1 {
    "Hello" | Set-Content file.txt
}

function Test1 {
    $path = ".\fie.txt"
    "Hello from PowerShell!" | Set-Content $path
    Write-Output "File written: $path"
}

function Test {
    "PID: $PID" | Out-File -FilePath "./fs/file.txt" -Encoding utf8
    # "abc" | Out-File -FilePath "./fs/file.txt" -Encoding utf8
}

Test
