<#
    Working with Files
#>

function Test1 {
    "Hello" | Set-Content file.txt
}

function Test1 {
    $path = ".\demo.txt"
    "Hello from PowerShell!" | Set-Content $path
    Write-Output "File written: $path"
}

function Test1 {
    Get-Content file.txt
}

function Test {
    $path = ".\demo.txt"
    $content = Get-Content $path
    Write-Output "File content:"
    Write-Output $content
}

Test
