
function Test1 {
    "Hello" | Set-Content file.txt
}

function Test {
    Get-Content file.txt
}

Test
