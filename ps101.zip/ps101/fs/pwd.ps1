<#
how do i print pwd in ps1?
#>

function Test1 {
    Get-Location
}

function Test1 {
    (Get-Location).Path
}

function Test1 {
    Write-Output Get-Location
    # Write-Output (Get-Location)
}

function Test1 {
    # Write-Output $PWD
    Write-Output $PWD.Path
}

function Test {
    '*** just like in bash ***'
    pwd
}

Test
