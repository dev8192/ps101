<#
A set of test folders

give me a ps1 script that creates the following fs tree:
dir1
    file1
    file2
    dir2
        file3
dir3
    file4
    dir4
file5
dir5

#>

$flatTree = @(
    @{ Path = "dir1";            Type = "Directory" },
    @{ Path = "dir1/file1";      Type = "File"      },
    @{ Path = "dir1/file2";      Type = "File"      },
    @{ Path = "dir1/dir2";       Type = "Directory" },
    @{ Path = "dir1/dir2/file3"; Type = "File"      },
    @{ Path = "dir3";            Type = "Directory" },
    @{ Path = "dir3/file4";      Type = "File"      },
    @{ Path = "dir3/dir4";       Type = "Directory" },
    @{ Path = "file5";           Type = "File"      },
    @{ Path = "dir5";            Type = "Directory" }
)
# $flatTree | ForEach-Object { New-Item -Path $_.Path -ItemType $_.Type -Force }

function test {
    $files = @(
        "dir1/file1",
        "dir1/file2",
        "dir1/dir2/file3",
        "dir3/file4",
        "dir3/dir4/dummy.txt",
        "file5"
    )
    foreach ($path in $files) {
        New-Item -Path $path -ItemType "File" -Force
    }
    New-Item -Path "dir5" -ItemType "Directory" -Force
    if (-not (Test-Path "dir3/dir4")) {
        'inside if'
        New-Item -Path "dir3/dir4" -ItemType "Directory" -Force 
    }
    Remove-Item "dir3/dir4/dummy.txt" -ErrorAction SilentlyContinue
}

# test
