$fsTree = @(
    @{ Name = "dir1"; Type = "Directory"; Children = @(
        @{ Name = "file1"; Type = "File" },
        @{ Name = "file2"; Type = "File" },
        @{ Name = "dir2"; Type = "Directory"; Children = @(
            @{ Name = "file3"; Type = "File" }
        )}
    )},
    @{ Name = "dir3"; Type = "Directory"; Children = @(
        @{ Name = "file4"; Type = "File" },
        @{ Name = "dir4"; Type = "Directory" }
    )},
    @{ Name = "file5"; Type = "File" },
    @{ Name = "dir5"; Type = "Directory" }
)

function Invoke-CreateTree ($items, $root = ".") {
    foreach ($item in $items) {
        $path = Join-Path $root $item.Name
        $type = if ($item.Type -eq "Directory") { "Directory" } else { "File" }
        
        New-Item -Path $path -ItemType $type -Force
        
        if ($item.Children) {
            Invoke-CreateTree -items $item.Children -root $path
        }
    }
}

Invoke-CreateTree -items $fsTree
