function IsNullOrWhiteSpace(str){
    if (str === null || str === undefined){
        return true
    }
    if (typeof str === 'string') {
        for (const ch of str) {
            if (!' \n\t'.includes(ch)) {
                return false
            }
        }
    }
    if (typeof str === 'boolean' || typeof str === 'number') {
        return false
    }
    return true
}

function IsNullOrWhiteSpace(str) {
    return (
        str === null || 
        str === undefined || (
            typeof str === 'string' && 
            str.trim().length === 0
        )
    )
}

console.log(IsNullOrWhiteSpace(null))
console.log(IsNullOrWhiteSpace(""))
console.log(IsNullOrWhiteSpace(" "))
console.log(IsNullOrWhiteSpace("\n"))
console.log(IsNullOrWhiteSpace("\t"))

console.log(IsNullOrWhiteSpace("5"))
console.log(IsNullOrWhiteSpace(" 5 "))
console.log(IsNullOrWhiteSpace(false))
console.log(IsNullOrWhiteSpace(true))
console.log(IsNullOrWhiteSpace(0))
console.log(IsNullOrWhiteSpace(123))
