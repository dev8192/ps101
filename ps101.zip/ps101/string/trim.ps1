
function Test {
    $text = " hello world "
    Write-Output "'$text'"
    Write-Output "'$($text.Trim())'"
    Write-Output "'$($text.TrimStart())'"
    Write-Output "'$($text.TrimEnd())'"
}

Test
