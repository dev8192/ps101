
function Test {
    $text = "PowerShell"
    Write-Output $text.ToUpper()
    Write-Output $text.ToLower()
}

# "powershell" --> "PowerShell"
function Test {
    $input = "powershell"
    $output = (
        $input.Substring(0,1).ToUpper() +
        $input.Substring(1,4) +
        $input.Substring(5,1).ToUpper() +
        $input.Substring(6)
    )
    Write-Host $output
}

function Test {
    $input = "powershell"
    $output = (
        $input[0].ToString().ToUpper() +
        $input.Substring(1,4) +
        $input[5].ToString().ToUpper() +
        $input.Substring(6)
    )
    Write-Host $output
}

function Test {
    $input = "powershell"
    $chars = $input.ToCharArray()
    # $chars = $input
    $chars[0] = $chars[0] - 32
    $chars[5] = $chars[5] - 32
    $output = -join $chars
    Write-Host $output
}

Test
