function Test {
    $string = "abcdef"
    $i = 0; $string.Remove($i, 1).Insert($i, "*")
    $i = 1; $string.Remove($i, 1).Insert($i, "*")
    $i = 2; $string.Remove($i, 1).Insert($i, "*")
    $i = 3; $string.Remove($i, 1).Insert($i, "*")
    $i = 4; $string.Remove($i, 1).Insert($i, "*")
    $i = 5; $string.Remove($i, 1).Insert($i, "*")
}

function Test {
    $str = "'one two three four five'"
    "$str"

    $str = $str.Remove(5, 15)
    "$str"
    
    $str = $str.Insert(5, "two three four ")
    "$str"
}

Test
