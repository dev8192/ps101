
function Test {
    # Write-Output "apple\nbanana\ncherry"
    Write-Output "apple`nbanana`ncherry"
}

Test
