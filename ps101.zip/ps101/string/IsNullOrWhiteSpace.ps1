
function test {
    [string]::IsNullOrWhiteSpace($null)
    [string]::IsNullOrWhiteSpace("")
    [string]::IsNullOrWhiteSpace(" ")
    [string]::IsNullOrWhiteSpace("`n")
    [string]::IsNullOrWhiteSpace("`t")
    
    [string]::IsNullOrWhiteSpace("5")
    [string]::IsNullOrWhiteSpace(" 5 ")
    [string]::IsNullOrWhiteSpace($false)
    [string]::IsNullOrWhiteSpace($true)
    [string]::IsNullOrWhiteSpace(0)
    [string]::IsNullOrWhiteSpace(123)
}

function test1 {
    $data = "Apple", "", "  ", "Banana", $null, "Cherry"
    $data | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
}

function test1 {
    function ParameterValidation {
        param(
            # [Parameter(Mandatory=$true)]
            [string]$UserName
        )

        if ([string]::IsNullOrWhiteSpace($UserName)) {
            Write-Host "User name cannot be empty"
        } else {
            Write-Host "Hello, $UserName!"
        }
    }
    ParameterValidation -UserName ""
    ParameterValidation -UserName " "
    ParameterValidation -UserName "Admin"
    'done'
}

test
