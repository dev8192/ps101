
function Test {
    $string = "abc"
    $string.IndexOf("a")
    $string.IndexOf("b")
    $string.IndexOf("c")
    $string.IndexOf("d")
    $string.IndexOf("e")
}

function Test {
    function Print-Message {
        param($str1, $str2)
        if ($str1.IndexOf($str2) -ge 0) {
            'found'
        } else {
            'not found'
        }
    }
    Print-Message "abc" "c"
    Print-Message "abc" "d"
}

Test