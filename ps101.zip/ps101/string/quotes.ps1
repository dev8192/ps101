
# single quotes vs double quotes
function Test {
    $fruits = "apple", "banana", "cherry"
    $fruits
    "$fruits"
    '$fruits'
}

function Test1 {
    $name = "Alice"
    $age = 30
    Write-Output "Next year $name will be $($age + 1)"
}

function Test {
    $x = 5

    $code = "$x"
    $code

    $code = '$x'
    $code

    $code = "`$x"
    $code
}

Test
