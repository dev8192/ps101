function Test {
    $str = 'one ' +
           'two ' +
           'three'
    $str
}

function Test {
    $a = "hello"
    $b = "world"
    # Write-Output ($a + " " + $b)
    # Write-Output $a + " " + $b
    $a + " " + $b
}

# TODO: do we really need this?
function Test1 {
    $a = "hello"
    $b = "world"
    Write-Output "$($a) $($b)"
}

function Test1 {
    $a = "hello"
    $b = "world"
    Write-Output "$a $b"
}

Test
