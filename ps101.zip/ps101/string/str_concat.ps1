function Test {
    $str = 'one ' +
           'two ' +
           'three'
    $str
}

Test
