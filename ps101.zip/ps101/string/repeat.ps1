function test {
    '------------------------------'
    '-' * 30
    New-Object String('-', 30)
}

function test {
    $result = ''
    for ($i = 0; $i -lt 30; $i++) {
        $result += '-'
    }
    $result
}

function test {
    function RepeatedString([string]$Char, [int]$Count) {
        Write-Host "$count"
        if ($Count -le 0) {
            return ""
        }
        return $Char + (RepeatedString -Char $Char -Count ($Count - 1))
    }
    RepeatedString -Char "-" -Count 3
}

test
