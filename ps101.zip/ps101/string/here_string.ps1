function Test {
    $one = 'ONE'
    $txt = @"
$one
two
three
"@
    $txt
}

function Test {
    $one = 'ONE'
    $txt = @'
$one
two
three
'@
    $txt
}

Test
