<#
    string.ps1
    Demonstrates common string operations in PowerShell.
#>

function Test {
    $text = "PowerShell"
    $text.Length
    $text[0]
    $text[$text.Length - 1]
    $text[$text.Length]
    $text[333]
    $text
}

function Test {
    $text = "PowerShell"
    Write-Output $text.Substring(0, 5)
    Write-Output $text.Substring(5)
}

function Test {
    $csv = "apple,banana,cherry"

    $parts = $csv -split ","
    Write-Output "$parts"

    $joined = $parts -join " | "
    Write-Output $joined
}

function Test {
    $text = "PowerShell scripting"
    Write-Output $text.Contains('Shell')
    Write-Output $text.StartsWith('Power')
    Write-Output $text.EndsWith('ing')
    Write-Output $text.Contains('abc')
}

function Test1 {
    $str = 'abcdefghijklmnopqrstuvwxyz'
    # $arr = $str.ToCharArray()
    $arr = 'abc'.ToCharArray()
    "$($arr)"
    $str.GetType().Name
    $arr.GetType().Name
}

Test
