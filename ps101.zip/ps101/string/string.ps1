<#
    string.ps1
    Demonstrates common string operations in PowerShell.
#>

# single quotes vs double quotes
function Test {
    $fruits = "apple", "banana", "cherry"
    $fruits
    "$fruits"
    '$fruits'
}

function Test1 {
    # Write-Output "apple\nbanana\ncherry"
    Write-Output "apple`nbanana`ncherry"
}

function Test1 {
    $name = "Alice"
    $age = 30
    Write-Output "Next year $($name) will be $($age + 1)"
}

function Test1 {
    $a = "hello"
    $b = "world"
    Write-Output ($a + " " + $b)
    Write-Output "$($a) $($b)"
}

function Test1 {
    $text = "PowerShell"
    Write-Output $($text.Length)
    Write-Output $($text[0])
    Write-Output $($text[$text.Length - 1])
}

function Test1 {
    $text = "PowerShell"
    Write-Output $text.Substring(0,5)
    Write-Output $text.Substring(5)
}

function Test1 {
    $csv = "apple,banana,cherry"

    $parts = $csv -split ","
    Write-Output $parts

    $joined = $parts -join " | "
    Write-Output $joined
}

function Test1 {
    $text = "I love JavaScript"
    Write-Output $text.Replace("JavaScript", "PowerShell")
}

function Test1 {
    $text = " hello world "
    Write-Output "'$text'"
    Write-Output "'$($text.Trim())'"
    Write-Output "'$($text.TrimStart())'"
    Write-Output "'$($text.TrimEnd())'"
}

function Test1 {
    $text = "PowerShell"
    Write-Output $text.ToUpper()
    Write-Output $text.ToLower()
}

function Test1 {
    $text = "PowerShell scripting"
    Write-Output $text.Contains('Shell')
    Write-Output $text.StartsWith('Power')
    Write-Output $text.EndsWith('ing')
    Write-Output $text.Contains('abc')
}

function Test {
    $block = @"
apple
banana
cherry
"@

    Write-Output $block
}

Test
