# replace all
function Test {
    $inputString = "aabbcc"
    $outputString = $inputString -replace "a", "5"
    Write-Host $outputString
}

function Test1 {
    $inputString = "powershell"
    $outputString = $inputString -replace "^p", "P" `
                                 -replace "shell$", "Shell"
    Write-Host $outputString
}

function Test {
    $text = "I love JavaScript"
    Write-Output $text.Replace("JavaScript", "PowerShell")
}

Test
