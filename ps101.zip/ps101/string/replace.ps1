# replace all
function test {
    $inputString = "aabbcc"
    $outputString = $inputString -replace "a", "5"
    Write-Host $outputString
}

function test {
    $inputString = "powershell"
    $outputString = $inputString -replace "^p", "P" `
                                 -replace "shell$", "Shell"
    Write-Host $outputString
}

function test {
    $text = "I love JavaScript"
    Write-Output $text.Replace("JavaScript", "PowerShell")
}

function test {
    $original = "The quick brown fox"
    $new = $original -replace "brown", "white"
    "Original: $original"
    "Replaced: $new"
}

test
