class Person {
    [string]$Name = 'Bob'
}

function Get-Greeting {
    param([string]$Name)
    "Hello, $Name!"
}
Export-ModuleMember -Function Get-Greeting
