using module ./module1.psm1
Import-Module ./module1.psm1

Get-Greeting -Name "Bob"

[Person]::new()
