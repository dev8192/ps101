# Import-Module ./MyModule -Force

using MyModule

# Get-Greeting1 -Name "Bob"

[asdf]::new()
