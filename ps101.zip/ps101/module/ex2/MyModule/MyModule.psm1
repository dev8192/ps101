# function Get-Greeting1 {
#     param([string]$Name)
#     "Hello, $Name!"
# }
# Export-ModuleMember -Function Get-Greeting1

class asdf {
    [string]$Name = 'Bob'
}

