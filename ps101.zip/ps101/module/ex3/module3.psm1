function Add {
    param($a, $b)
    return $a + $b
}
function Subtract {
    param($a, $b)
    return $a - $b
}
function Multiply {
    param($a, $b)
    return $a * $b
}
function Divide {
    param($a, $b)
    return $a / $b
}

# Export-ModuleMember -Function *
