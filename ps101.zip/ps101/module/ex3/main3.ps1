Import-Module ./module3.psm1 -Force

Add 2 3
Subtract 5 1
Multiply 3 4
Divide 10 2
