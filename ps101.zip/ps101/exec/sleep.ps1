function Test1 {
    'start'
    Start-Sleep -Seconds 3
    'end'
}

function Test1 {
    for ($i = 0; $i -lt 5; $i++) {
        $i
        Start-Sleep -Seconds 1
    }
}

function Test {
    $numbers = 'one', 'two', 'three', 'four', 'five'
    for ($i = 0; $i -lt $numbers.count; $i++) {
        $numbers[$i]
        Start-Sleep -Seconds 1
    }
}

function Test1 {
    $task = { "$(Get-Date)" }
    "$(Get-Date)"
    Start-Sleep -Seconds 5
    & $task
}

Test
