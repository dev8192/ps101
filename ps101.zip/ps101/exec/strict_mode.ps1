Set-StrictMode -Version 2.0
try {
    Write-Host $hello
    'before catch'
} catch { 
    'inside catch'
}
'after catch'
