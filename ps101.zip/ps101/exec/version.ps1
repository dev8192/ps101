function Test {
    $PSVersionTable.PSVersion
}

function Test {
    $PSVersionTable.PSVersion.Major
    $PSVersionTable.PSVersion.Minor
    $PSVersionTable.PSVersion.Build
    $PSVersionTable.PSVersion.Revision
}

function Test {
    $base = 2
    $exponent = 3
    if ($PSVersionTable.PSVersion.Major -ge 7) {
        # $base ** $exponent
        # $sb = {$base ** $exponent}
        $sb = [scriptblock]::Create("$base ** $exponent")
        &$sb
    } else {
        [Math]::Pow($base, $exponent)
    }
}

Test
