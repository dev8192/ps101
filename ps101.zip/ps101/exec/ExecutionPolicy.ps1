<#
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine

Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

Set-ExecutionPolicy Bypass -Scope Process
Unblock-File -Path script.ps1
powershell -ExecutionPolicy Bypass -File script.ps1
#>


