function Test {
    $arr = 5, 3, 9, 1, 7
    "$arr"
    "$($arr | Sort-Object)"
    "$($arr | Sort-Object -Descending)"
}

function Test {
    Get-ChildItem -Path C:/yt/ps101
    # Get-ChildItem -Path C:/yt/ps101 | Sort-Object
}

function test1 {
    $colors = "Red", "Blue", "Green", "Yellow"
    $colors | Sort-Object -Descending
}

function test {
    $names = "System", "User", "Administrator", "Guest"
    # $names | Sort-Object -Property @{Expression={$_.Length}}
    $names | Sort-Object -Property @{Expression={$_.Length}} -Descending
}

test
