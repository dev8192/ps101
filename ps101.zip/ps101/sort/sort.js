function test() {
    let names = ["System", "User", "Administrator", "Guest"]
    names.sort((a, b) => {
        return a.length - b.length
        // return b.length - a.length
    })
    console.log(names)
}

test()
