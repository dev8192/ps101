function Test {
    # Get-ChildItem -Path C:/yt/ps101 | Sort-Object
    Get-ChildItem -Path C:/yt/ps101
}

Test
