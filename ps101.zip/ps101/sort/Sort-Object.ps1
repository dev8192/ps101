function Test {
    # Get-ChildItem -Path C:/yt/ps101 | Sort-Object
    Get-ChildItem -Path C:/yt/ps101
}

function Test {
    $arr = 5, 3, 9, 1, 7

    Write-Output "Original: $arr"
    Write-Output "Sorted ascending:   $($arr | Sort-Object)"
    Write-Output "Sorted descending:  $($arr | Sort-Object -Descending)"
}

Test
