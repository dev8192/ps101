function test {
    $numbers = 5, 2, 8, 1, 9
    $numbers | Sort-Object
}

function test {
    $colors = "Red", "Blue", "Green", "Yellow"
    $colors | Sort-Object -Descending
}

function test {
    Get-ChildItem -File
    # Get-ChildItem -File | Sort-Object -Property Length
}

# 4. Multi-Property Sorting: Sorts by a primary property, then a secondary one if ties occur.
function Sort-ByMultipleProperties {
    Write-Host "--- Sorting Processes by Name, then ID ---"
    Get-Process | Sort-Object -Property ProcessName, Id | Select-Object -First 10
}

# 5. Unique Sorting: Removes duplicate values while sorting.
function Sort-UniqueValues {
    $list = "Apple", "Banana", "Apple", "Orange", "Banana"
    Write-Host "--- Unique Sorted List ---"
    $list | Sort-Object -Unique
}

# 6. Mixed Direction Sorting: Uses hash tables to sort different properties in different directions.
function Sort-MixedDirections {
    Write-Host "--- Services: Status (Desc), then Name (Asc) ---"
    # Status: Running (4) > Stopped (1). Descending puts Running first.
    Get-Service | Sort-Object -Property @{Expression="Status"; Descending=$true}, @{Expression="DisplayName"; Ascending=$true} | Select-Object -First 10
}

# 7. Calculated Property Sorting: Sorts based on a logic-driven value (e.g., string length).
function Sort-ByCalculatedProperty {
    $names = "System", "User", "Administrator", "Guest"
    Write-Host "--- Sorting by Name Length ---"
    $names | Sort-Object -Property @{Expression={$_.Length}}
}

# 8. Hashtable Sorting: Uses GetEnumerator to sort keys/values in a dictionary.
function Sort-HashtableEntries {
    $hash = @{ "Zebra"=10; "Apple"=50; "Monkey"=5 }
    Write-Host "--- Sorting Hashtable by Key ---"
    $hash.GetEnumerator() | Sort-Object -Property Name
}

test
