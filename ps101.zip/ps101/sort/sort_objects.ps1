<#

give me a ps1 script that sorts an array of person objects:
-- by name
-- by age

#>
$people = @(
    [PSCustomObject]@{ Name = "ф"; Age = 34 }
    [PSCustomObject]@{ Name = "b";    Age = 25 }
    [PSCustomObject]@{ Name = "c
    ";   Age = 40 }
    [PSCustomObject]@{ Name = "d";    Age = 22 }
)

# function test {
#     $data | Sort-Object -Property Name
#     # $data | Sort-Object -Property Name | Format-Table
# }

# function Sort-ByPersonAge {
#     $data | Sort-Object -Property Age | Format-Table
# }

# function Sort-ByMultipleFields {
#     # $data | Sort-Object -Property Name, @{Expression="Age"; Descending=$true} | Format-Table
# }

# test
