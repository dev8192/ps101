
$data = @(
    [PSCustomObject]@{ Name = "Bob";   Age = 30 }
    [PSCustomObject]@{ Name = "Bob";   Age = 25 }
    [PSCustomObject]@{ Name = "Jack";  Age = 40 }
    [PSCustomObject]@{ Name = "Alice"; Age = 34 }
    [PSCustomObject]@{ Name = "John";  Age = 22 }
)

function test {
    # $data | Sort-Object -Property Name
    $data | Sort-Object -Property Age
}

function test {
    # $data | Sort-Object -Property Name, Age
    $data | Sort-Object -Property @{Expression="Name"; Descending=$true}
}

test
