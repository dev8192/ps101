function test {
    function Safe-Invoke {
        param([ScriptBlock]$Action)
        try {
            & $Action
        }
        catch {
            # "Error: $($_.Exception.Message)"
            # "Error: $($_)"
            # $_
            # $_.Exception
            $_.Exception.Message
        }
    }
    Safe-Invoke { 1 / 0 }
    'done'
}

test
