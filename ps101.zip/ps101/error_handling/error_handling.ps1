
function Test1 {
    try {
        Get-Item "C:\this\path\does\not\exist.txt" -ErrorAction Stop
    } catch {
        Write-Warning "Something went wrong:"
        Write-Warning $_.Exception.Message
    }
}

function Test {
    try {
        Write-Host "Attempting division..." -ForegroundColor Gray
        $result = 10 / 0
        Write-Host "Result: $result"
    } catch {
        Write-Host "Error Caught: $_" -ForegroundColor Red
    } finally {
        Write-Host "Cleanup complete (Finally block always runs)." -ForegroundColor Gray
    }
}

Test
