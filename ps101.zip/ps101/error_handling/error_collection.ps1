
function Test {
    # 5 / 2
    5 / 0
}

Test
