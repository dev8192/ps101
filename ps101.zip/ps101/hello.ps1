Get-Content .\TaskbarVisibility.ps1 -Stream Zone.Identifier
