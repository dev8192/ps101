if (-not ("Greeter" -as [type])) {
    Add-Type -TypeDefinition @"
public static class Greeter {
    public static string SayHello(string name) {
        return "Hello, " + name + " from C#!";
    }
}
"@
}

Write-Output ([Greeter]::SayHello("PowerShell"))
