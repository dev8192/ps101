# Add-Type -Path "c_sharp/add_type_path/file15.cs"
Add-Type -Path "file15.cs"
[Hello]::Say()
