/*
Expression‑bodied methods (=>) require C# 6 or newer.
*/

public class Hello {
    public static string Say() => "Hello 555";
}
