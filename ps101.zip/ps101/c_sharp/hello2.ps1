
# Add a C# class dynamically
Add-Type -TypeDefinition @"
using System;
public static class Greeter {
    public static string SayHello(string name)     {
        return $"Hello, {name} from C#!";
    }
}
"@

$message = [Greeter]::SayHello("PowerShell")
Write-Output $message
