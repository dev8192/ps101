# embedding C# code inside PowerShell

Add-Type @"
public class Hello {
    public static string Say() => "Hello from C#";
}
"@

[Hello]::Say()
