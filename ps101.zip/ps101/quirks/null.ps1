<#
No difference because $var is scalar
#>
function test {
    $var = 123
    $var -eq $null
    $null -eq $var
}

<#
Null on the Left: equality
Null on the Right: filtering
#>
function test {
    $arr = @()
    '$null -eq $arr: ' + "$($null -eq $arr)"
    '$arr -eq $null: ' + "$($arr -eq $null)"
}

function test1 {
    $arr1 = @(123)
    -not $arr1
    $arr2 = @()
    -not $arr2
}

function test1 {
    # $arr1 = @($null, $null, $null)
    $arr1 = @(5, 10, 15)
    # $arr1 = @($null, 3.14)
    # $arr1 = @()
    $arr1.count
    $arr2 = $arr1 -eq $null
    $arr2.count
}

test
