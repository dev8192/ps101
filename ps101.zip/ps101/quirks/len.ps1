function Test {
    $str = "PowerShell"
    $str.Length

    $arr = "apple", "banana", "cherry"
    $arr.Count
}

Test
