<#
You must specify an object for the Get-Member cmdlet.
#>

function test {
    $arr = @()
    $arr | Get-Member
    # ,$arr | Get-Member
}

test
