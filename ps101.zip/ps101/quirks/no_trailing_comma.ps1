$arr = @(
    'apple',
    'banana',
    'orange',
    # 'kiwi'
)

$arr