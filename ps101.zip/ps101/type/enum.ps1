enum Status {
    Started
    Running
    Finished
}

function Test1 {
    [Status]::Started
    [Status]::Running
    [Status]::Finished
}

function Test {
    # [Status]$State = [Status]::Started
    [Status]$State = 'hello'
    $State
}

Test
