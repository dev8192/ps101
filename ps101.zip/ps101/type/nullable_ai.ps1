
function test {
    # $age = $null
    # [int]$age = $null
    [Nullable[int]]$age = $null
    $age
    Write-Host "Initial value is null: $($null -eq $age)"
    $age = 25
    Write-Host "Assigned value: $age"
}

function test {
    [Nullable[decimal]]$price = $null
    if (-not $price.HasValue) {
        Write-Host "Price is currently unknown."
    }   
    $price = 99.99
    if ($price.HasValue) {
        Write-Host "Price set to: $($price.Value)"
    }
}

# 4. Получение значения по умолчанию (GetValueOrDefault)
function Demo-DefaultValue {
    [Nullable[int]]$points = $null
    
    # Если $null, вернет 0 (дефолт для int) или заданное значение
    $result = $points.GetValueOrDefault(-1)
    
    Write-Host "Result with default: $result"
}

test
