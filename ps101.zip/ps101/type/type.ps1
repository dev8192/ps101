
# All types (8?)
function Test1 {
    $var = 123          ; $var.GetType().Name
    $var = 3.14         ; $var.GetType().Name
    $var = $true        ; $var.GetType().Name
    $var = "apple"      ; $var.GetType().Name
    $var = @(123)       ; $var.GetType().Name
    $var = Get-Date     ; $var.GetType().Name

    $var = @{
        Name = "Alex"
        Age = 30
        City = "Moscow"
    }
    $var.GetType().Name

    $var = [PSCustomObject]@{
        Make = "Toyota"
        Model = "Camry"
        Year = 2023
    }
    $var.GetType().Name
}

function Test1 {
    $var = @(123)
    $var.GetType().Name

    $var = 123
    $var.GetType().Name

    $var = @("apple")
    $var.GetType().Name

    $var = "apple"
    $var.GetType().Name
}

function Test1 {
    [int]$intNum = 123
    $intNum
    $intNum.GetType().Name

    $intNum = 456
    $intNum
    $intNum.GetType().Name
}

function Test {
    $arr = "red", "green", "blue"
    $arr.GetType().Name
    $arr[0].GetType().Name
}

Test
