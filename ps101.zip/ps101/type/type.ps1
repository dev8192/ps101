
# All types (9?)
function Test {
    function Print-Info {
        param($var)
        # $var.GetType().Name
        $var.GetType()
    }
    $var = 123                 ; Print-Info $var
    $var = 3.14                ; Print-Info $var
    $var = $true               ; Print-Info $var
    $var = Get-Date            ; Print-Info $var

    $var = @(5, 10, 15)        ; Print-Info $var
    $var = @('a', 'b', 'c')    ; Print-Info $var
    $var = 1..10               ; Print-Info $var
    $var = [int[]](1..10)      ; Print-Info $var
    $var = 'abc'.ToCharArray() ; Print-Info $var

    $var = "apple"             ; Print-Info $var

    $var = @{
        Name = "Alex"
        Age = 30
        City = "Moscow"
    }
    Print-Info $var

    $var = [PSCustomObject]@{
        Make = "Toyota"
        Model = "Camry"
        Year = 2023
    }
    Print-Info $var

    $var = { "This is a scriptblock" }
    Print-Info $var
}

function Test1 {
    $var = @(123)
    $var.GetType().Name

    $var = 123
    $var.GetType().Name

    $var = @("apple")
    $var.GetType().Name

    $var = "apple"
    $var.GetType().Name
}

function Test1 {
    [int]$intNum = 123
    $intNum
    $intNum.GetType().Name

    $intNum = 456
    $intNum
    $intNum.GetType().Name
}

function Test1 {
    $arr = "red", "green", "blue"
    $arr.GetType().Name
    $arr[0].GetType().Name
}

Test
