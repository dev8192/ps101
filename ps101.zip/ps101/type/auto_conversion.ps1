<#
PowerShell is a weakly typed language and
will often attempt to convert types automatically
#>