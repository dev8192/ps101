function test {
    function func {
        param($IsActive)
        switch ($IsActive) {
            $true   { "Active" }
            $false  { "Inactive" }
            $null   { "Unknown" }
            default { "Default" }
        }
    }
    func $true
    func $false
    func $null
    func 'hello'
    func 333
}

function test {
    function func {
        param([bool]$IsActive)
        switch ($IsActive) {
            $true   { "Active" }
            $false  { "Inactive" }
            $null   { "Unknown" }
            default { "Default" }
        }
    }
    func $true
    func 333
    func $false
}

function test1 {
    function func {
        param([Nullable[bool]]$IsActive)
        switch ($IsActive) {
            $true   { "Active" }
            $false  { "Inactive" }
            $null   { "Unknown" }
            default { "Default" }
        }
    }
    func $true
    func 333
    func $false
    func $null
}

test
