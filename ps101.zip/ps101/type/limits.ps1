function Test {
    [int]::MaxValue # 2147483647
    [int]::MinValue # -2147483648
}

function Test {
    [int]::MaxValue.ToString('x') # 7fffffff
    [int]::MinValue.ToString('x') # 80000000
}

Test
