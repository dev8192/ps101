
function test {
    $list = New-Object System.Collections.ArrayList
    $list.GetType().FullName

    $cast = $list -as [System.Collections.IList]
    $cast.GetType().FullName
}

function test {
    $list = New-Object System.Collections.ArrayList
    '*************** ArrayList ***************'
    ,$list | Get-Member
    '*************** IList ***************'
    ,($list -as [System.Collections.IList]) | Get-Member
}

test
