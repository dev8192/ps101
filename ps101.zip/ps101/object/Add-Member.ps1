
function Test {
    $obj = [PSCustomObject]@{ Name = "Alice" }
    $obj | Add-Member -NotePropertyName "Age" -NotePropertyValue 30
    "$obj"
}

Test
