
function Test {
    $person = [PSCustomObject]@{
        Name = "Alice"
        Age  = 30
    }
    "Name: $($person.Name), Age: $($person.Age)"
    $person.Age++
    "Name: $($person.Name), Age: $($person.Age)"
}

Test
