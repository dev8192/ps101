function Test {
    $car = [PSCustomObject]@{
        Make = "Toyota"
        Model = "Camry"
        Year = 2023
    }
    $car
    $car | Format-List
}

Test
