function test {
    $person = [PSCustomObject]@{
        name = 'Vasya'
        city = 'Moscow'
    }
    "$person"
    # $person | Add-Member -MemberType NoteProperty -Name "age" -Value 30
    $person | Add-Member -NotePropertyName "age" -NotePropertyValue 30
    "$person"
    $person.PSObject.Properties.Remove('city')
    "$person"
}

test
