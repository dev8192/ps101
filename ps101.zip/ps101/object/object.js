function test() {
    const person = {name: 'Vasya', city: 'Moscow'}
    console.log(person)
    person.age = 30
    console.log(person)
    delete person.city
    console.log(person)
}

test()
