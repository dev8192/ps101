<#
powershell -File script.ps1 -ContentParameters @{Encoding="UTF8"}
powershell -File create_utf8bom.ps1 -ContentParameters @{Encoding="UTF8"}
#>
