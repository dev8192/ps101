ps101 is a set of exercises for people who want to learn how to automate Windows.
It covers:
-- PowerShell syntax and semantics
-- Standard library (cmdlets)
-- Integration with C# and access to win32
-- Common administrative tasks
