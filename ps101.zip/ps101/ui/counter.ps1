Add-Type -AssemblyName PresentationFramework

$script:counter = 0

$window = New-Object System.Windows.Window
$window.Title = "Counter Demo"
$window.Width = 250
$window.Height = 150
$window.WindowStartupLocation = "CenterScreen"

$panel = New-Object System.Windows.Controls.StackPanel
$panel.HorizontalAlignment = "Center"
$panel.VerticalAlignment = "Center"
$panel.Margin = 10

$label = New-Object System.Windows.Controls.Label
$label.FontSize = 24
$label.HorizontalContentAlignment = "Center"
$label.Content = "Count: $script:counter"

$button = New-Object System.Windows.Controls.Button
$button.Content = "Increment"
$button.Width = 100
$button.Margin = 5
$button.Add_Click({
    $script:counter++
    $label.Content = "Count: $script:counter"
})
$panel.Children.Add($label)
$panel.Children.Add($button)
$window.Content = $panel
$window.ShowDialog() | Out-Null
