Add-Type -AssemblyName PresentationFramework

$window = New-Object System.Windows.Window
$window.Title = "Demo"
$window.Width = 250
$window.Height = 120
$window.WindowStartupLocation = "CenterScreen"

$label = New-Object System.Windows.Controls.Label
$label.Content = "Hello World"
$label.FontSize = 24
$label.HorizontalContentAlignment = "Center"
$label.VerticalContentAlignment = "Center"
$window.Content = $label

$window.Show()
Start-Sleep -Seconds 30
$window.Close()
