<#
give me a powershell script that create a file with utf8 bom encoding with the following content: "привет мир"


i have a powershell file that prints "привет мир". It prints "РїСЂРёРІРµС‚ РјРёСЂ". how to fix?
#>

$content = "привет мир"
$path = "hello.txt"
$content
# $content | Out-File -FilePath $path
$content | Out-File -FilePath $path -Encoding utf8
