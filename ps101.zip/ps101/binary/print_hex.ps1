function test {
    # Format-Hex -Path "hello.txt" -Count 3
    Format-Hex -Path "hello.txt"
}

test
