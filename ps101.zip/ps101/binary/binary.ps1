function Test {
    [Convert]::ToString(15, 2).PadLeft(8, '0')
    [Convert]::ToString(128 -bor 64 -bor 32 -bor 16, 2).PadLeft(8, '0')
}

function Test {
    # $num = 15
    $num = [int]::MaxValue
    $num.ToString('X')
    $num.ToString('x')
}

Test
