function Test {
    [Convert]::ToString(15, 2).PadLeft(8, '0')
    [Convert]::ToString(128 -bor 64 -bor 32 -bor 16, 2).PadLeft(8, '0')
}

function Test {
    [int]::MaxValue
    [int]::MinValue

    [int]::MaxValue.ToString('X')
    [int]::MinValue.ToString('X')
    
    [Convert]::ToString([int]::MaxValue, 2).PadLeft(64, '0')
    [Convert]::ToString([int]::MinValue, 2).PadLeft(64, '0')
}

Test
