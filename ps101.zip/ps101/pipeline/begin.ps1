
function test {
    $sb = {
        begin   { "Begin block" }
        process { "Processing $_" }
        end     { "End block" }
    }

    1..3 | & $sb
}

test
