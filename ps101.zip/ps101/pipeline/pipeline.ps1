<#
    func1 | func2 | func3
    func3(func2(func1()))
#>

function test {
    1..5 | ForEach-Object { $_ * 2 }
}

function test1 {
    1..10 | Where-Object { $_ -gt 5 }
}

test
