function test() {
    function range(start, end) {
        const arr = []
        for (let i = start; i <= end; i++) {
            arr.push(i)
        }
        return arr
    }
    // console.log(range(1, 5).map($_ => $_ * 2))
    // range(1, 5).forEach(($_) => console.log($_ * 2))

    function forEachObject(arr, callback) {
        for (const item of arr) {
            callback(item)
        }
    }
    forEachObject(range(1, 5), $_ => console.log($_ * 2))
}

test()
